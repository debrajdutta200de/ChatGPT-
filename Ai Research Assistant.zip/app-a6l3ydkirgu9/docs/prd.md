# The Ghost AI Research Assistant Requirements Document

## 1. Application Overview

**Application Name:** The Ghost AI Research Assistant

**Application Logo:** Use the uploaded image 15883.png as the application logo

**Application Description:** An AI-powered research platform designed to help users collect, analyze, organize, and generate research materials automatically. The system integrates artificial intelligence with knowledge management tools to support academic research workflows.

**Target Users:** Students, academic researchers, developers, journalists, analysts

**Developer Information:**
- Developer Name: Debraj Dutta
- Developer Photo: Use the uploaded image 15822.png
- Phone Number: 8536943389
- Address: Debraj Dutta's house, kalikapur, kumrul, Hooghly, West Bengal, India
- Email: debrajdutta200de@gmail.com

**Admin Email:** debrajdutta200de@gmail.com

## 2. Core AI Research System

### 2.1 Webpage Summarization
- Users provide single or multiple URLs
- Processing pipeline: Fetch webpage HTML, remove scripts and advertisements, extract main article content, clean formatting and remove noise, send processed text to AI summarization engine
- Output: short summary, key bullet points, important insights, simplified explanation
- Additional features: batch summarization, adjustable summary length, export summaries

### 2.2 AI Literature Review Generator
- Users provide: research topic, research question, list of research sources
- AI engine extracts key arguments, groups sources by themes, compares viewpoints, detects research gaps
- Output: structured literature review, key themes, comparison table, citation list

### 2.3 Automatic Research Report Generator
- Users select research materials from the library
- AI engine generates structured report with sections: Title, Abstract, Introduction, Literature Review, Key Findings, Discussion, Conclusion, References
- Export formats: PDF, DOCX, Markdown

### 2.4 Voice Research Assistant
- Voice interaction with supported commands: Summarize this article, Explain this topic, Generate citations, Search research library
- Components: speech recognition, AI processing, text-to-speech response

### 2.5 AI Knowledge Graph Builder
- Automatically builds visual knowledge network
- Processing steps: extract key concepts, identify relationships between concepts, generate graph nodes and edges
- Interactive graph structure: Topic → subtopics → related sources

## 3. Collaborative Research Workspace

- Multiple users can collaborate on shared research projects
- Features: shared research projects, shared research library, collaborative notes, comment threads, task assignment
- User roles: Owner (full project control), Collaborator (edit and add research items), Viewer (read-only access)

## 4. Citation Generator

- Automatically generates academic citations from URLs
- Supported formats: APA, MLA, Chicago, Harvard
- Features: automatic citation from URL, bibliography builder, citation export

## 5. Research Library (Knowledge Management)

- Stored data types: webpages, summaries, notes, citations, reports, uploaded PDFs
- Organization tools: folders, tags, filters, search engine

## 6. Security Tools

### 6.1 URL Security Scanner
- Analyzes URLs to detect: phishing websites, malware risk, suspicious domains

### 6.2 Tracker Detection
- Analyzes webpage scripts to detect: advertising trackers, analytics trackers, fingerprinting scripts

### 6.3 Password Strength Analyzer
- Evaluates passwords and outputs: entropy score, strength rating, estimated crack time

## 7. Productivity Tools

- Integrated features: screenshot capture, OCR text extraction, webpage highlighting, annotation system, PDF reader, note editor

## 8. Developer Code Workspace

### 8.1 Code Viewer
- Display generated website code including HTML and CSS
- Syntax highlighting for better readability
- Code structure organized by file type

### 8.2 AI-Powered Code Editor
- Interactive coding environment where developers can write and edit code using AI assistance
- AI features: code completion, code generation from natural language prompts, code optimization suggestions, error detection and fixes
- Supported languages: HTML, CSS, JavaScript

### 8.3 Browser Preview
- Real-time browser preview of coded website
- Run and test code directly in the browser
- Instant refresh when code changes are made
- Responsive preview for different screen sizes

### 8.4 Code Extraction from Website Link
- Developers can extract code from any website URL
- Processing pipeline: User provides website URL, system fetches webpage HTML, extracts HTML structure, CSS styles, and JavaScript code, organizes extracted code by file type
- Integration: Uses Gemini API for intelligent code extraction and analysis
- Gemini API Configuration: API endpoint for code extraction, authentication using API key, request format includes target URL and extraction options, response includes structured code files
- Output: Extracted HTML, CSS, and JavaScript code displayed in the code viewer
- Features: Clean and formatted code output, ability to edit extracted code, save extracted code to projects

## 9. Dashboard Interface

### Main Sections
- Dashboard
- Summarizer
- Literature Review
- Research Reports
- Library
- Security Tools
- Workspace
- Developer Code Workspace
- Settings

## 10. Settings Page

### Account Management
- Profile information: edit name, email, phone number, address, profile photo
- Password management: change password, password strength indicator
- Account security: enable/disable two-factor authentication, view active sessions, logout from all devices
- Account deletion: option to permanently delete account with confirmation

### Application Preferences
- Theme settings: light mode, dark mode, auto (system default)
- Language preferences: select interface language
- Notification settings: email notifications, in-app notifications, notification frequency
- Privacy settings: enable/disable analytics tracking, data sharing preferences
- Default settings: default summary length, default citation format, default export format
- API configuration: manage API keys, view API usage statistics
- Storage management: view storage usage, clear cache, manage saved items

## 11. User Authentication & Access Control

### Authentication Methods
- Email + password login
- Google OAuth
- GitHub OAuth

### Security Measures
- Password hashing (bcrypt)
- JWT authentication
- Session expiration
- Optional two-factor authentication

## 12. Analytics Integration

Include the following Google Analytics tracking script:

```html
<!-- Google tag (gtag.js) -->
<script async src=\"https://www.googletagmanager.com/gtag/js?id=G-HPC8QLV5V6\"></script>
<script>
window.dataLayer = window.dataLayer || [];
function gtag(){dataLayer.push(arguments);}
gtag('js', new Date());
gtag('config', 'G-HPC8QLV5V6');
</script>
```

Analytics must automatically disable when privacy mode is enabled.

## 13. API Structure

### Core APIs
- POST /api/summarize
- POST /api/literature-review
- POST /api/report-generate
- POST /api/citation
- POST /api/url-scan
- POST /api/password-check
- POST /api/voice-command

### Library APIs
- POST /api/library/save
- GET /api/library/items
- DELETE /api/library/remove

### Developer Workspace APIs
- GET /api/code/view
- POST /api/code/generate
- POST /api/code/execute
- POST /api/code/save
- POST /api/code/extract

### Settings APIs
- GET /api/settings/profile
- PUT /api/settings/profile
- PUT /api/settings/password
- PUT /api/settings/preferences
- GET /api/settings/sessions
- DELETE /api/settings/session
- DELETE /api/settings/account

## 14. Database Schema

### Main Tables
- Users
- Projects
- ResearchItems
- Summaries
- Notes
- Citations
- Reports
- KnowledgeGraphNodes
- KnowledgeGraphEdges
- CodeProjects
- UserSettings
- UserSessions

### Relationships
- Users → Projects
- Projects → ResearchItems
- ResearchItems → Summaries
- ResearchItems → Notes
- ResearchItems → Citations
- Users → CodeProjects
- Users → UserSettings
- Users → UserSessions

## 15. Non-Functional Requirements

### Performance
- Summaries generated within 10 seconds
- Support 1000 concurrent users
- Code execution and browser preview within 3 seconds
- Code extraction from website link within 15 seconds
- Settings page load within 2 seconds

### Scalability
- System must support horizontal scaling using containerized services

### Security
- Encrypted connections (HTTPS)
- Secure authentication
- Protection against injection attacks
- Code execution in sandboxed environment
- Secure API key management for Gemini API
- Secure storage of user preferences and settings

### Privacy
- User research data must remain private
- Analytics tracking must disable in privacy mode
- User settings and preferences stored securely