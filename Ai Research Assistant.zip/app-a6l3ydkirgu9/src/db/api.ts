import { supabase } from './supabase';
import type {
  Profile,
  Project,
  ProjectMember,
  Folder,
  Tag,
  ResearchItem,
  Summary,
  Note,
  Citation,
  Report,
  KnowledgeGraphNode,
  KnowledgeGraphEdge,
  ProjectWithMembers,
  ResearchItemWithDetails,
  CitationFormat,
  ResearchItemType,
  ProjectMemberRole,
} from '@/types';

// ============= Profile APIs =============
export async function getCurrentProfile(): Promise<Profile | null> {
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', (await supabase.auth.getUser()).data.user?.id || '')
    .maybeSingle();
  
  if (error) throw error;
  return data;
}

export async function getAllProfiles(): Promise<Profile[]> {
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .order('created_at', { ascending: false });
  
  if (error) throw error;
  return Array.isArray(data) ? data : [];
}

export async function updateProfile(id: string, updates: Partial<Profile>): Promise<void> {
  const { error } = await supabase
    .from('profiles')
    .update(updates)
    .eq('id', id);
  
  if (error) throw error;
}

// ============= Project APIs =============
export async function getProjects(): Promise<ProjectWithMembers[]> {
  const { data, error } = await supabase
    .from('projects')
    .select(`
      *,
      project_members!inner(
        *,
        profiles(*)
      )
    `)
    .order('created_at', { ascending: false });
  
  if (error) throw error;
  return Array.isArray(data) ? data : [];
}

export async function getProjectById(id: string): Promise<ProjectWithMembers | null> {
  const { data, error } = await supabase
    .from('projects')
    .select(`
      *,
      project_members(
        *,
        profiles(*)
      )
    `)
    .eq('id', id)
    .maybeSingle();
  
  if (error) throw error;
  return data;
}

export async function createProject(project: {
  name: string;
  description?: string;
}): Promise<Project> {
  const user = (await supabase.auth.getUser()).data.user;
  if (!user) throw new Error('Not authenticated');

  const { data, error } = await supabase
    .from('projects')
    .insert({
      name: project.name,
      description: project.description || null,
      created_by: user.id,
    })
    .select()
    .single();
  
  if (error) throw error;

  // Add creator as owner
  await supabase.from('project_members').insert({
    project_id: data.id,
    user_id: user.id,
    role: 'owner' as ProjectMemberRole,
  });

  return data;
}

export async function updateProject(id: string, updates: Partial<Project>): Promise<void> {
  const { error } = await supabase
    .from('projects')
    .update(updates)
    .eq('id', id);
  
  if (error) throw error;
}

export async function deleteProject(id: string): Promise<void> {
  const { error } = await supabase
    .from('projects')
    .delete()
    .eq('id', id);
  
  if (error) throw error;
}

// ============= Project Member APIs =============
export async function addProjectMember(
  projectId: string,
  userId: string,
  role: ProjectMemberRole
): Promise<void> {
  const { error } = await supabase
    .from('project_members')
    .insert({
      project_id: projectId,
      user_id: userId,
      role,
    });
  
  if (error) throw error;
}

export async function updateProjectMemberRole(
  projectId: string,
  userId: string,
  role: ProjectMemberRole
): Promise<void> {
  const { error } = await supabase
    .from('project_members')
    .update({ role })
    .eq('project_id', projectId)
    .eq('user_id', userId);
  
  if (error) throw error;
}

export async function removeProjectMember(projectId: string, userId: string): Promise<void> {
  const { error } = await supabase
    .from('project_members')
    .delete()
    .eq('project_id', projectId)
    .eq('user_id', userId);
  
  if (error) throw error;
}

// ============= Folder APIs =============
export async function getFolders(): Promise<Folder[]> {
  const { data, error } = await supabase
    .from('folders')
    .select('*')
    .order('name');
  
  if (error) throw error;
  return Array.isArray(data) ? data : [];
}

export async function createFolder(name: string, parentId?: string): Promise<Folder> {
  const user = (await supabase.auth.getUser()).data.user;
  if (!user) throw new Error('Not authenticated');

  const { data, error } = await supabase
    .from('folders')
    .insert({
      name,
      user_id: user.id,
      parent_id: parentId || null,
    })
    .select()
    .single();
  
  if (error) throw error;
  return data;
}

export async function deleteFolder(id: string): Promise<void> {
  const { error } = await supabase
    .from('folders')
    .delete()
    .eq('id', id);
  
  if (error) throw error;
}

// ============= Tag APIs =============
export async function getTags(): Promise<Tag[]> {
  const { data, error } = await supabase
    .from('tags')
    .select('*')
    .order('name');
  
  if (error) throw error;
  return Array.isArray(data) ? data : [];
}

export async function createTag(name: string): Promise<Tag> {
  const user = (await supabase.auth.getUser()).data.user;
  if (!user) throw new Error('Not authenticated');

  const { data, error } = await supabase
    .from('tags')
    .insert({
      name,
      user_id: user.id,
    })
    .select()
    .single();
  
  if (error) throw error;
  return data;
}

// ============= Research Item APIs =============
export async function getResearchItems(filters?: {
  projectId?: string;
  folderId?: string;
  itemType?: ResearchItemType;
  search?: string;
}): Promise<ResearchItemWithDetails[]> {
  let query = supabase
    .from('research_items')
    .select(`
      *,
      summaries(*),
      notes(*),
      citations(*),
      research_item_tags(tags(*))
    `)
    .order('created_at', { ascending: false });

  if (filters?.projectId) {
    query = query.eq('project_id', filters.projectId);
  }
  if (filters?.folderId) {
    query = query.eq('folder_id', filters.folderId);
  }
  if (filters?.itemType) {
    query = query.eq('item_type', filters.itemType);
  }
  if (filters?.search) {
    query = query.or(`title.ilike.%${filters.search}%,content.ilike.%${filters.search}%`);
  }

  const { data, error } = await query;
  
  if (error) throw error;
  return Array.isArray(data) ? data : [];
}

export async function getResearchItemById(id: string): Promise<ResearchItemWithDetails | null> {
  const { data, error } = await supabase
    .from('research_items')
    .select(`
      *,
      summaries(*),
      notes(*),
      citations(*),
      research_item_tags(tags(*))
    `)
    .eq('id', id)
    .maybeSingle();
  
  if (error) throw error;
  return data;
}

export async function createResearchItem(item: {
  title: string;
  url?: string;
  content?: string;
  item_type: ResearchItemType;
  project_id?: string;
  folder_id?: string;
  metadata?: Record<string, unknown>;
}): Promise<ResearchItem> {
  const user = (await supabase.auth.getUser()).data.user;
  if (!user) throw new Error('Not authenticated');

  const { data, error } = await supabase
    .from('research_items')
    .insert({
      title: item.title,
      url: item.url || null,
      content: item.content || null,
      item_type: item.item_type,
      user_id: user.id,
      project_id: item.project_id || null,
      folder_id: item.folder_id || null,
      metadata: item.metadata || {},
    })
    .select()
    .single();
  
  if (error) throw error;
  return data;
}

export async function updateResearchItem(
  id: string,
  updates: Partial<ResearchItem>
): Promise<void> {
  const { error } = await supabase
    .from('research_items')
    .update(updates)
    .eq('id', id);
  
  if (error) throw error;
}

export async function deleteResearchItem(id: string): Promise<void> {
  const { error } = await supabase
    .from('research_items')
    .delete()
    .eq('id', id);
  
  if (error) throw error;
}

// ============= Summary APIs =============
export async function createSummary(summary: {
  research_item_id: string;
  summary_text: string;
  key_points: string[];
  insights?: string;
}): Promise<Summary> {
  const user = (await supabase.auth.getUser()).data.user;
  if (!user) throw new Error('Not authenticated');

  const { data, error } = await supabase
    .from('summaries')
    .insert({
      research_item_id: summary.research_item_id,
      summary_text: summary.summary_text,
      key_points: summary.key_points,
      insights: summary.insights || null,
      user_id: user.id,
    })
    .select()
    .single();
  
  if (error) throw error;
  return data;
}

// ============= Note APIs =============
export async function createNote(note: {
  research_item_id: string;
  content: string;
}): Promise<Note> {
  const user = (await supabase.auth.getUser()).data.user;
  if (!user) throw new Error('Not authenticated');

  const { data, error } = await supabase
    .from('notes')
    .insert({
      research_item_id: note.research_item_id,
      content: note.content,
      user_id: user.id,
    })
    .select()
    .single();
  
  if (error) throw error;
  return data;
}

export async function updateNote(id: string, content: string): Promise<void> {
  const { error } = await supabase
    .from('notes')
    .update({ content })
    .eq('id', id);
  
  if (error) throw error;
}

export async function deleteNote(id: string): Promise<void> {
  const { error } = await supabase
    .from('notes')
    .delete()
    .eq('id', id);
  
  if (error) throw error;
}

// ============= Citation APIs =============
export async function createCitation(citation: {
  research_item_id: string;
  format: CitationFormat;
  citation_text: string;
}): Promise<Citation> {
  const user = (await supabase.auth.getUser()).data.user;
  if (!user) throw new Error('Not authenticated');

  const { data, error } = await supabase
    .from('citations')
    .insert({
      research_item_id: citation.research_item_id,
      format: citation.format,
      citation_text: citation.citation_text,
      user_id: user.id,
    })
    .select()
    .single();
  
  if (error) throw error;
  return data;
}

// ============= Report APIs =============
export async function getReports(projectId?: string): Promise<Report[]> {
  let query = supabase
    .from('reports')
    .select('*')
    .order('created_at', { ascending: false });

  if (projectId) {
    query = query.eq('project_id', projectId);
  }

  const { data, error } = await query;
  
  if (error) throw error;
  return Array.isArray(data) ? data : [];
}

export async function createReport(report: {
  title: string;
  content: string;
  project_id?: string;
  metadata?: Record<string, unknown>;
}): Promise<Report> {
  const user = (await supabase.auth.getUser()).data.user;
  if (!user) throw new Error('Not authenticated');

  const { data, error } = await supabase
    .from('reports')
    .insert({
      title: report.title,
      content: report.content,
      project_id: report.project_id || null,
      user_id: user.id,
      metadata: report.metadata || {},
    })
    .select()
    .single();
  
  if (error) throw error;
  return data;
}

export async function deleteReport(id: string): Promise<void> {
  const { error } = await supabase
    .from('reports')
    .delete()
    .eq('id', id);
  
  if (error) throw error;
}

// ============= Knowledge Graph APIs =============
export async function getKnowledgeGraph(projectId: string): Promise<{
  nodes: KnowledgeGraphNode[];
  edges: KnowledgeGraphEdge[];
}> {
  const [nodesResult, edgesResult] = await Promise.all([
    supabase
      .from('knowledge_graph_nodes')
      .select('*')
      .eq('project_id', projectId),
    supabase
      .from('knowledge_graph_edges')
      .select('*')
      .eq('project_id', projectId),
  ]);

  if (nodesResult.error) throw nodesResult.error;
  if (edgesResult.error) throw edgesResult.error;

  return {
    nodes: Array.isArray(nodesResult.data) ? nodesResult.data : [],
    edges: Array.isArray(edgesResult.data) ? edgesResult.data : [],
  };
}

export async function createKnowledgeGraphNode(node: {
  project_id: string;
  label: string;
  node_type: string;
  metadata?: Record<string, unknown>;
}): Promise<KnowledgeGraphNode> {
  const { data, error } = await supabase
    .from('knowledge_graph_nodes')
    .insert(node)
    .select()
    .single();
  
  if (error) throw error;
  return data;
}

export async function createKnowledgeGraphEdge(edge: {
  project_id: string;
  source_node_id: string;
  target_node_id: string;
  relationship: string;
}): Promise<KnowledgeGraphEdge> {
  const { data, error } = await supabase
    .from('knowledge_graph_edges')
    .insert(edge)
    .select()
    .single();
  
  if (error) throw error;
  return data;
}
