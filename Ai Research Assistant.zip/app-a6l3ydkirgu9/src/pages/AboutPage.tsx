import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Mail, Phone, MapPin, User, Building } from 'lucide-react';

export default function AboutPage() {
  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="space-y-2">
        <h1 className="text-3xl font-bold">About The Ghost AI Research Assistant</h1>
        <p className="text-muted-foreground">
          An AI-powered research platform designed to help users collect, analyze, organize, and generate research materials automatically
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Application Info */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Building className="h-5 w-5" />
              <span>Application Information</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-center py-6">
              <img 
                src="https://miaoda-conversation-file.s3cdn.medo.dev/user-a6hulcpt29z4/conv-a6l3ydkirgu8/20260311/file-a6s4tqdz1a0w.png" 
                alt="The Ghost AI Logo" 
                className="h-32 w-32 object-contain"
              />
            </div>
            <div className="space-y-2">
              <h3 className="font-semibold text-lg">The Ghost AI Research Assistant</h3>
              <p className="text-sm text-muted-foreground">
                A comprehensive research platform integrating artificial intelligence with knowledge management tools to support academic research workflows.
              </p>
            </div>
            <div className="pt-4 border-t space-y-2">
              <h4 className="font-medium">Key Features:</h4>
              <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground">
                <li>AI-Powered Webpage Summarization</li>
                <li>Literature Review Generator</li>
                <li>Automatic Research Report Generation</li>
                <li>Collaborative Workspace</li>
                <li>Security Tools (URL Scanner, Password Analyzer)</li>
                <li>Developer Playground with Code Extraction</li>
                <li>Research Library Management</li>
              </ul>
            </div>
            <div className="pt-4 border-t">
              <p className="text-sm text-muted-foreground">
                <strong>Admin Contact:</strong> debrajdutta200de@gmail.com
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Developer Info */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <User className="h-5 w-5" />
              <span>Developer Information</span>
            </CardTitle>
            <CardDescription>
              Meet the creator of The Ghost AI Research Assistant
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-center">
              <img 
                src="https://miaoda-conversation-file.s3cdn.medo.dev/user-a6hulcpt29z4/conv-a6l3ydkirgu8/20260311/file-a6s4ulyguby8.png" 
                alt="Debraj Dutta" 
                className="h-40 w-40 rounded-full object-cover border-4 border-primary"
              />
            </div>
            
            <div className="space-y-4">
              <div className="text-center">
                <h3 className="font-bold text-xl">Debraj Dutta</h3>
                <p className="text-sm text-muted-foreground">Full Stack Developer</p>
              </div>

              <div className="space-y-3 pt-4">
                <div className="flex items-start space-x-3">
                  <Mail className="h-5 w-5 text-muted-foreground mt-0.5" />
                  <div>
                    <p className="text-sm font-medium">Email</p>
                    <a 
                      href="mailto:debrajdutta200de@gmail.com" 
                      className="text-sm text-primary hover:underline"
                    >
                      debrajdutta200de@gmail.com
                    </a>
                  </div>
                </div>

                <div className="flex items-start space-x-3">
                  <Phone className="h-5 w-5 text-muted-foreground mt-0.5" />
                  <div>
                    <p className="text-sm font-medium">Phone</p>
                    <a 
                      href="tel:+918536943389" 
                      className="text-sm text-primary hover:underline"
                    >
                      +91 8536943389
                    </a>
                  </div>
                </div>

                <div className="flex items-start space-x-3">
                  <MapPin className="h-5 w-5 text-muted-foreground mt-0.5" />
                  <div>
                    <p className="text-sm font-medium">Address</p>
                    <p className="text-sm text-muted-foreground">
                      Debraj Dutta's house<br />
                      Kalikapur, Kumrul<br />
                      Hooghly, West Bengal<br />
                      India
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Copyright */}
      <Card>
        <CardContent className="py-6 text-center">
          <p className="text-sm text-muted-foreground">
            © 2026 The Ghost AI Research Assistant. All rights reserved.
          </p>
          <p className="text-xs text-muted-foreground mt-2">
            Developed with ❤️ by Debraj Dutta
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
