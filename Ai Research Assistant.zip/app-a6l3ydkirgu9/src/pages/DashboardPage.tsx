import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { FileText, BookOpen, FileBarChart, Library, TrendingUp, Clock } from 'lucide-react';
import { getResearchItems, getReports, getProjects } from '@/db/api';
import type { ResearchItem, Report, Project } from '@/types';

export default function DashboardPage() {
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    researchItems: 0,
    reports: 0,
    projects: 0,
  });
  const [recentItems, setRecentItems] = useState<ResearchItem[]>([]);
  const [recentReports, setRecentReports] = useState<Report[]>([]);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      const [items, reports, projects] = await Promise.all([
        getResearchItems(),
        getReports(),
        getProjects(),
      ]);

      setStats({
        researchItems: items.length,
        reports: reports.length,
        projects: projects.length,
      });

      setRecentItems(items.slice(0, 5));
      setRecentReports(reports.slice(0, 5));
    } catch (error) {
      console.error('Error loading dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  const statCards = [
    {
      title: 'Research Items',
      value: stats.researchItems,
      icon: Library,
      description: 'Total items in library',
      href: '/library',
    },
    {
      title: 'Reports Generated',
      value: stats.reports,
      icon: FileBarChart,
      description: 'Research reports created',
      href: '/reports',
    },
    {
      title: 'Active Projects',
      value: stats.projects,
      icon: BookOpen,
      description: 'Collaborative workspaces',
      href: '/workspace',
    },
  ];

  return (
    <div className="container mx-auto p-6 space-y-8">
      {/* Welcome Section */}
      <div className="space-y-2">
        <h1 className="text-4xl font-bold gradient-text">Welcome to The Ghost AI Research Assistant</h1>
        <p className="text-muted-foreground text-lg">
          Your intelligent research companion for collecting, analyzing, and organizing research materials
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid gap-6 md:grid-cols-3">
        {loading ? (
          <>
            {[1, 2, 3].map((i) => (
              <Card key={i}>
                <CardHeader>
                  <Skeleton className="h-4 w-32 bg-muted" />
                  <Skeleton className="h-8 w-16 bg-muted" />
                </CardHeader>
              </Card>
            ))}
          </>
        ) : (
          statCards.map((stat) => {
            const Icon = stat.icon;
            return (
              <Link key={stat.title} to={stat.href}>
                <Card className="hover:border-primary transition-colors cursor-pointer">
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
                    <Icon className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-primary">{stat.value}</div>
                    <p className="text-xs text-muted-foreground mt-1">{stat.description}</p>
                  </CardContent>
                </Card>
              </Link>
            );
          })
        )}
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
          <CardDescription>Start your research workflow</CardDescription>
        </CardHeader>
        <CardContent className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Button asChild variant="outline" className="w-full h-auto flex-col py-4 space-y-2">
            <Link to="/summarizer">
              <FileText className="h-6 w-6" />
              <span>Summarize Webpage</span>
            </Link>
          </Button>
          <Button asChild variant="outline" className="w-full h-auto flex-col py-4 space-y-2">
            <Link to="/literature-review">
              <BookOpen className="h-6 w-6" />
              <span>Generate Review</span>
            </Link>
          </Button>
          <Button asChild variant="outline" className="w-full h-auto flex-col py-4 space-y-2">
            <Link to="/reports">
              <FileBarChart className="h-6 w-6" />
              <span>Create Report</span>
            </Link>
          </Button>
          <Button asChild variant="outline" className="w-full h-auto flex-col py-4 space-y-2">
            <Link to="/library">
              <Library className="h-6 w-6" />
              <span>Browse Library</span>
            </Link>
          </Button>
        </CardContent>
      </Card>

      {/* Recent Activity */}
      <div className="grid gap-6 md:grid-cols-2">
        {/* Recent Research Items */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Clock className="h-5 w-5" />
              <span>Recent Research Items</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="space-y-3">
                {[1, 2, 3].map((i) => (
                  <Skeleton key={i} className="h-16 w-full bg-muted" />
                ))}
              </div>
            ) : recentItems.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-8">
                No research items yet. Start by summarizing a webpage!
              </p>
            ) : (
              <div className="space-y-3">
                {recentItems.map((item) => (
                  <Link
                    key={item.id}
                    to={`/library?item=${item.id}`}
                    className="block p-3 rounded-lg border border-border hover:border-primary transition-colors"
                  >
                    <h4 className="font-medium text-sm line-clamp-1">{item.title}</h4>
                    <p className="text-xs text-muted-foreground mt-1">
                      {new Date(item.created_at).toLocaleDateString()}
                    </p>
                  </Link>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Recent Reports */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <TrendingUp className="h-5 w-5" />
              <span>Recent Reports</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="space-y-3">
                {[1, 2, 3].map((i) => (
                  <Skeleton key={i} className="h-16 w-full bg-muted" />
                ))}
              </div>
            ) : recentReports.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-8">
                No reports yet. Generate your first research report!
              </p>
            ) : (
              <div className="space-y-3">
                {recentReports.map((report) => (
                  <Link
                    key={report.id}
                    to={`/reports?report=${report.id}`}
                    className="block p-3 rounded-lg border border-border hover:border-primary transition-colors"
                  >
                    <h4 className="font-medium text-sm line-clamp-1">{report.title}</h4>
                    <p className="text-xs text-muted-foreground mt-1">
                      {new Date(report.created_at).toLocaleDateString()}
                    </p>
                  </Link>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
