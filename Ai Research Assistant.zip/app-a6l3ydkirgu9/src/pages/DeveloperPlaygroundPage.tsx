import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Label } from '@/components/ui/label';
import { Code, Play, Sparkles, Loader2, Download, Copy, RotateCcw, Link as LinkIcon } from 'lucide-react';
import { toast } from 'sonner';
import { supabase } from '@/db/supabase';

const DEFAULT_HTML = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>My Web Page</title>
</head>
<body>
  <h1>Hello, World!</h1>
  <p>Welcome to the Developer Playground</p>
</body>
</html>`;

const DEFAULT_CSS = `body {
  font-family: Arial, sans-serif;
  margin: 0;
  padding: 20px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
}

h1 {
  font-size: 3rem;
  margin-bottom: 1rem;
  text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
}

p {
  font-size: 1.2rem;
  opacity: 0.9;
}`;

const DEFAULT_JS = `// Add your JavaScript code here
console.log('Developer Playground loaded!');

// Example: Add click event
document.addEventListener('DOMContentLoaded', () => {
  const heading = document.querySelector('h1');
  if (heading) {
    heading.addEventListener('click', () => {
      alert('Hello from JavaScript!');
    });
  }
});`;

export default function DeveloperPlaygroundPage() {
  const [html, setHtml] = useState(DEFAULT_HTML);
  const [css, setCss] = useState(DEFAULT_CSS);
  const [js, setJs] = useState(DEFAULT_JS);
  const [aiPrompt, setAiPrompt] = useState('');
  const [extractUrl, setExtractUrl] = useState('');
  const [generating, setGenerating] = useState(false);
  const [extracting, setExtracting] = useState(false);
  const [previewKey, setPreviewKey] = useState(0);

  const generatePreview = () => {
    const combinedCode = `
      <!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>${css}</style>
      </head>
      <body>
        ${html.replace(/<!DOCTYPE html>|<html[^>]*>|<\/html>|<head[^>]*>|<\/head>|<body[^>]*>|<\/body>/gi, '')}
        <script>${js}<\/script>
      </body>
      </html>
    `;
    return combinedCode;
  };

  const handleRunCode = () => {
    setPreviewKey((prev) => prev + 1);
    toast.success('Code executed!');
  };

  const handleAIGenerate = async () => {
    if (!aiPrompt.trim()) {
      toast.error('Please enter a prompt');
      return;
    }

    setGenerating(true);
    try {
      const codeContext = `HTML:\n${html}\n\nCSS:\n${css}\n\nJavaScript:\n${js}`;
      
      const { data, error } = await supabase.functions.invoke('ai-code-assistant', {
        body: { 
          prompt: aiPrompt,
          code_context: codeContext,
        },
      });

      if (error) {
        const errorMsg = await error?.context?.text();
        throw new Error(errorMsg || error.message);
      }

      const generatedCode = data.code;

      // Parse the generated code to extract HTML, CSS, and JS
      const htmlMatch = generatedCode.match(/```html\n([\s\S]*?)```/i) || 
                       generatedCode.match(/<html[\s\S]*<\/html>/i);
      const cssMatch = generatedCode.match(/```css\n([\s\S]*?)```/i) ||
                      generatedCode.match(/<style>([\s\S]*?)<\/style>/i);
      const jsMatch = generatedCode.match(/```javascript\n([\s\S]*?)```/i) ||
                     generatedCode.match(/```js\n([\s\S]*?)```/i) ||
                     generatedCode.match(/<script>([\s\S]*?)<\/script>/i);

      if (htmlMatch) {
        setHtml(htmlMatch[1] || htmlMatch[0]);
      }
      if (cssMatch) {
        setCss(cssMatch[1] || cssMatch[0]);
      }
      if (jsMatch) {
        setJs(jsMatch[1] || jsMatch[0]);
      }

      // If no specific sections found, try to parse as complete HTML
      if (!htmlMatch && !cssMatch && !jsMatch) {
        if (generatedCode.includes('<!DOCTYPE') || generatedCode.includes('<html')) {
          setHtml(generatedCode);
        } else {
          toast.info('Code generated - please review and adjust as needed');
          // Try to intelligently place the code
          if (generatedCode.includes('{') && generatedCode.includes('}')) {
            setCss(generatedCode);
          } else if (generatedCode.includes('function') || generatedCode.includes('const') || generatedCode.includes('let')) {
            setJs(generatedCode);
          } else {
            setHtml(generatedCode);
          }
        }
      }

      toast.success('Code generated successfully!');
      setAiPrompt('');
      handleRunCode();
    } catch (error: any) {
      console.error('Error generating code:', error);
      toast.error(error.message || 'Failed to generate code');
    } finally {
      setGenerating(false);
    }
  };

  const handleExtractFromUrl = async () => {
    if (!extractUrl.trim()) {
      toast.error('Please enter a URL');
      return;
    }

    // Validate URL format
    try {
      new URL(extractUrl);
    } catch {
      toast.error('Please enter a valid URL');
      return;
    }

    setExtracting(true);
    try {
      const { data, error } = await supabase.functions.invoke('extract-code-from-url', {
        body: { url: extractUrl },
      });

      if (error) {
        const errorMsg = await error?.context?.text();
        throw new Error(errorMsg || error.message);
      }

      if (data.html) {
        setHtml(data.html);
      }
      if (data.css) {
        setCss(data.css);
      }
      if (data.javascript) {
        setJs(data.javascript);
      }

      toast.success('Code extracted successfully!');
      setExtractUrl('');
      handleRunCode();
    } catch (error: any) {
      console.error('Error extracting code:', error);
      toast.error(error.message || 'Failed to extract code from URL');
    } finally {
      setExtracting(false);
    }
  };

  const handleCopyCode = () => {
    const fullCode = generatePreview();
    navigator.clipboard.writeText(fullCode);
    toast.success('Code copied to clipboard!');
  };

  const handleDownload = () => {
    const fullCode = generatePreview();
    const blob = new Blob([fullCode], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'index.html';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast.success('Code downloaded!');
  };

  const handleReset = () => {
    setHtml(DEFAULT_HTML);
    setCss(DEFAULT_CSS);
    setJs(DEFAULT_JS);
    setPreviewKey((prev) => prev + 1);
    toast.success('Code reset to default');
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="space-y-2">
        <h1 className="text-3xl font-bold flex items-center space-x-2">
          <Code className="h-8 w-8" />
          <span>Developer Playground</span>
        </h1>
        <p className="text-muted-foreground">
          Write HTML, CSS, and JavaScript code with AI assistance and see live preview
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Code Editor Section */}
        <div className="space-y-4">
          {/* URL Code Extractor */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 text-base">
                <LinkIcon className="h-5 w-5" />
                <span>Extract Code from Website</span>
              </CardTitle>
              <CardDescription>
                Enter a website URL to extract and analyze its code
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <Input
                type="url"
                placeholder="https://example.com"
                value={extractUrl}
                onChange={(e) => setExtractUrl(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleExtractFromUrl()}
              />
              <Button onClick={handleExtractFromUrl} disabled={extracting} className="w-full">
                {extracting ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Extracting Code...
                  </>
                ) : (
                  <>
                    <LinkIcon className="h-4 w-4 mr-2" />
                    Extract Code
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          {/* AI Assistant */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 text-base">
                <Sparkles className="h-5 w-5" />
                <span>AI Coding Assistant</span>
              </CardTitle>
              <CardDescription>
                Describe what you want to build and AI will generate the code
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <Textarea
                placeholder="E.g., Create a responsive card with a gradient background and hover effect"
                value={aiPrompt}
                onChange={(e) => setAiPrompt(e.target.value)}
                rows={3}
              />
              <Button onClick={handleAIGenerate} disabled={generating} className="w-full">
                {generating ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    <Sparkles className="h-4 w-4 mr-2" />
                    Generate Code
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          {/* Code Tabs */}
          <Card className="flex-1">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-base">Code Editor</CardTitle>
                <div className="flex space-x-2">
                  <Button variant="outline" size="sm" onClick={handleReset}>
                    <RotateCcw className="h-4 w-4" />
                  </Button>
                  <Button variant="outline" size="sm" onClick={handleCopyCode}>
                    <Copy className="h-4 w-4" />
                  </Button>
                  <Button variant="outline" size="sm" onClick={handleDownload}>
                    <Download className="h-4 w-4" />
                  </Button>
                  <Button size="sm" onClick={handleRunCode}>
                    <Play className="h-4 w-4 mr-2" />
                    Run
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="html" className="w-full">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="html">HTML</TabsTrigger>
                  <TabsTrigger value="css">CSS</TabsTrigger>
                  <TabsTrigger value="js">JavaScript</TabsTrigger>
                </TabsList>
                <TabsContent value="html" className="space-y-2">
                  <Label>HTML Code</Label>
                  <Textarea
                    value={html}
                    onChange={(e) => setHtml(e.target.value)}
                    className="font-mono text-sm min-h-[400px]"
                    placeholder="Enter HTML code..."
                  />
                </TabsContent>
                <TabsContent value="css" className="space-y-2">
                  <Label>CSS Code</Label>
                  <Textarea
                    value={css}
                    onChange={(e) => setCss(e.target.value)}
                    className="font-mono text-sm min-h-[400px]"
                    placeholder="Enter CSS code..."
                  />
                </TabsContent>
                <TabsContent value="js" className="space-y-2">
                  <Label>JavaScript Code</Label>
                  <Textarea
                    value={js}
                    onChange={(e) => setJs(e.target.value)}
                    className="font-mono text-sm min-h-[400px]"
                    placeholder="Enter JavaScript code..."
                  />
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>

        {/* Preview Section */}
        <div className="space-y-4">
          <Card className="h-full">
            <CardHeader>
              <CardTitle className="text-base">Live Preview</CardTitle>
              <CardDescription>
                See your code in action
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="border-2 border-border rounded-lg overflow-hidden bg-white">
                <iframe
                  key={previewKey}
                  srcDoc={generatePreview()}
                  title="Preview"
                  sandbox="allow-scripts"
                  className="w-full h-[600px] bg-white"
                />
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
