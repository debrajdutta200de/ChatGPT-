import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Loader2, BookOpen, Download } from 'lucide-react';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';

export default function LiteratureReviewPage() {
  const [topic, setTopic] = useState('');
  const [researchQuestion, setResearchQuestion] = useState('');
  const [sources, setSources] = useState('');
  const [loading, setLoading] = useState(false);
  const [review, setReview] = useState('');

  const handleGenerate = async () => {
    if (!topic || !researchQuestion) {
      toast.error('Please enter topic and research question');
      return;
    }

    setLoading(true);
    setReview('');

    try {
      const prompt = `Generate a comprehensive literature review on the following topic:

Topic: ${topic}
Research Question: ${researchQuestion}
${sources ? `Sources to consider:\n${sources}` : ''}

Please provide:
1. An introduction to the topic
2. Key themes and findings from the literature
3. Comparison of different viewpoints
4. Research gaps identified
5. Conclusion and future directions

Format the response in a structured academic style.`;

      const { data, error } = await supabase.functions.invoke('ai-summarize', {
        body: { prompt },
      });

      if (error) {
        throw error;
      }

      setReview(data.text);
      toast.success('Literature review generated!');
    } catch (error) {
      console.error('Error generating review:', error);
      toast.error('Failed to generate literature review');
    } finally {
      setLoading(false);
    }
  };

  const handleExport = () => {
    const content = `# Literature Review: ${topic}

**Research Question:** ${researchQuestion}

${review}
`;

    const blob = new Blob([content], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `literature_review_${topic.replace(/[^a-z0-9]/gi, '_')}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="space-y-2">
        <h1 className="text-3xl font-bold">Literature Review Generator</h1>
        <p className="text-muted-foreground">
          Generate comprehensive literature reviews using AI
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Research Details</CardTitle>
          <CardDescription>Provide information about your research topic</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="topic">Research Topic</Label>
            <Input
              id="topic"
              placeholder="e.g., Machine Learning in Healthcare"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              disabled={loading}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="question">Research Question</Label>
            <Input
              id="question"
              placeholder="e.g., How does ML improve diagnostic accuracy?"
              value={researchQuestion}
              onChange={(e) => setResearchQuestion(e.target.value)}
              disabled={loading}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="sources">Sources (Optional)</Label>
            <Textarea
              id="sources"
              placeholder="List your sources, one per line..."
              value={sources}
              onChange={(e) => setSources(e.target.value)}
              disabled={loading}
              rows={5}
            />
          </div>

          <Button onClick={handleGenerate} disabled={loading}>
            {loading ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Generating...
              </>
            ) : (
              <>
                <BookOpen className="h-4 w-4 mr-2" />
                Generate Review
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {review && (
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Generated Literature Review</CardTitle>
              <Button variant="outline" size="sm" onClick={handleExport}>
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="prose prose-sm max-w-none">
              <pre className="whitespace-pre-wrap text-sm leading-relaxed">{review}</pre>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
