import { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { FileBarChart, Download, Plus, Loader2 } from 'lucide-react';
import { getReports, createReport, getResearchItems } from '@/db/api';
import type { Report, ResearchItem } from '@/types';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';
import { supabase } from '@/db/supabase';

export default function ReportsPage() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [reports, setReports] = useState<Report[]>([]);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [creating, setCreating] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [researchItems, setResearchItems] = useState<ResearchItem[]>([]);
  const [formData, setFormData] = useState({
    title: '',
    topic: '',
    selectedItems: [] as string[],
    format: 'markdown' as 'markdown' | 'pdf' | 'docx',
  });

  useEffect(() => {
    loadReports();
    loadResearchItems();
  }, []);

  const loadReports = async () => {
    try {
      const data = await getReports();
      setReports(data);
    } catch (error) {
      console.error('Error loading reports:', error);
      toast.error('Failed to load reports');
    } finally {
      setLoading(false);
    }
  };

  const loadResearchItems = async () => {
    try {
      const data = await getResearchItems();
      setResearchItems(data);
    } catch (error) {
      console.error('Error loading research items:', error);
    }
  };

  const handleGenerateReport = async () => {
    if (!user) {
      toast.error('You must be logged in to create a report');
      return;
    }

    if (!formData.title.trim()) {
      toast.error('Report title is required');
      return;
    }

    if (!formData.topic.trim()) {
      toast.error('Research topic is required');
      return;
    }

    setGenerating(true);
    try {
      // Call AI to generate report content
      const { data: aiData, error: aiError } = await supabase.functions.invoke('ai-summarize', {
        body: {
          prompt: `Generate a comprehensive research report on the topic: "${formData.topic}". 
          
Include the following sections:
1. Title
2. Abstract (brief summary)
3. Introduction
4. Literature Review
5. Key Findings
6. Discussion
7. Conclusion
8. References

Format the report in markdown with proper headings and structure.`,
        },
      });

      if (aiError) {
        const errorMsg = await aiError?.context?.text();
        throw new Error(errorMsg || aiError.message);
      }

      const reportContent = aiData?.content || 'Report generation failed';

      // Save report to database
      setCreating(true);
      await createReport({
        title: formData.title.trim(),
        content: reportContent,
        metadata: { format: formData.format },
      });

      toast.success('Report generated successfully');
      setDialogOpen(false);
      setFormData({ title: '', topic: '', selectedItems: [], format: 'markdown' });
      loadReports();
    } catch (error: any) {
      console.error('Error generating report:', error);
      toast.error(error.message || 'Failed to generate report');
    } finally {
      setGenerating(false);
      setCreating(false);
    }
  };

  const handleDownloadReport = (report: Report) => {
    const blob = new Blob([report.content], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${report.title.replace(/[^a-z0-9]/gi, '_').toLowerCase()}.md`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast.success('Report downloaded');
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div className="space-y-2">
          <h1 className="text-3xl font-bold">Research Reports</h1>
          <p className="text-muted-foreground">
            Generate and manage your research reports
          </p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              New Report
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Generate Research Report</DialogTitle>
              <DialogDescription>
                Create an AI-generated research report with structured sections
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="title">Report Title *</Label>
                <Input
                  id="title"
                  placeholder="Enter report title"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="topic">Research Topic *</Label>
                <Textarea
                  id="topic"
                  placeholder="Enter the research topic or question"
                  value={formData.topic}
                  onChange={(e) => setFormData({ ...formData, topic: e.target.value })}
                  rows={3}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="format">Export Format</Label>
                <Select
                  value={formData.format}
                  onValueChange={(value) => setFormData({ ...formData, format: value as 'markdown' | 'pdf' | 'docx' })}
                >
                  <SelectTrigger id="format">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="markdown">Markdown</SelectItem>
                    <SelectItem value="pdf">PDF</SelectItem>
                    <SelectItem value="docx">DOCX</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setDialogOpen(false)} disabled={generating || creating}>
                Cancel
              </Button>
              <Button onClick={handleGenerateReport} disabled={generating || creating}>
                {generating || creating ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Generating...
                  </>
                ) : (
                  'Generate Report'
                )}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {loading ? (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {[1, 2, 3].map((i) => (
            <Card key={i}>
              <CardHeader>
                <Skeleton className="h-4 w-full bg-muted" />
                <Skeleton className="h-3 w-24 bg-muted" />
              </CardHeader>
            </Card>
          ))}
        </div>
      ) : reports.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center space-y-4">
            <FileBarChart className="h-12 w-12 mx-auto text-muted-foreground" />
            <div>
              <p className="text-lg font-medium">No reports yet</p>
              <p className="text-sm text-muted-foreground">
                Create your first research report to get started
              </p>
            </div>
            <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Create Report
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>Generate Research Report</DialogTitle>
                  <DialogDescription>
                    Create an AI-generated research report with structured sections
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label htmlFor="title-empty">Report Title *</Label>
                    <Input
                      id="title-empty"
                      placeholder="Enter report title"
                      value={formData.title}
                      onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="topic-empty">Research Topic *</Label>
                    <Textarea
                      id="topic-empty"
                      placeholder="Enter the research topic or question"
                      value={formData.topic}
                      onChange={(e) => setFormData({ ...formData, topic: e.target.value })}
                      rows={3}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="format-empty">Export Format</Label>
                    <Select
                      value={formData.format}
                      onValueChange={(value) => setFormData({ ...formData, format: value as 'markdown' | 'pdf' | 'docx' })}
                    >
                      <SelectTrigger id="format-empty">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="markdown">Markdown</SelectItem>
                        <SelectItem value="pdf">PDF</SelectItem>
                        <SelectItem value="docx">DOCX</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setDialogOpen(false)} disabled={generating || creating}>
                    Cancel
                  </Button>
                  <Button onClick={handleGenerateReport} disabled={generating || creating}>
                    {generating || creating ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        Generating...
                      </>
                    ) : (
                      'Generate Report'
                    )}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {reports.map((report) => (
            <Card key={report.id} className="hover:border-primary transition-colors">
              <CardHeader>
                <CardTitle className="text-base line-clamp-2">{report.title}</CardTitle>
                <CardDescription>
                  {new Date(report.created_at).toLocaleDateString()}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground line-clamp-3">
                  {report.content.substring(0, 150)}...
                </p>
                <div className="mt-4 flex space-x-2">
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button variant="outline" size="sm" className="flex-1">
                        View
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
                      <DialogHeader>
                        <DialogTitle>{report.title}</DialogTitle>
                        <DialogDescription>
                          Created on {new Date(report.created_at).toLocaleDateString()}
                        </DialogDescription>
                      </DialogHeader>
                      <div className="prose prose-sm max-w-none dark:prose-invert">
                        <pre className="whitespace-pre-wrap text-sm">{report.content}</pre>
                      </div>
                    </DialogContent>
                  </Dialog>
                  <Button variant="outline" size="sm" onClick={() => handleDownloadReport(report)}>
                    <Download className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
