import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Shield, AlertTriangle, CheckCircle, Loader2, Info } from 'lucide-react';
import { toast } from 'sonner';
import { supabase } from '@/db/supabase';

export default function SecurityPage() {
  const [urlToScan, setUrlToScan] = useState('');
  const [password, setPassword] = useState('');
  const [scanLoading, setScanLoading] = useState(false);
  const [passwordLoading, setPasswordLoading] = useState(false);
  const [scanResult, setScanResult] = useState<any>(null);
  const [passwordResult, setPasswordResult] = useState<any>(null);

  const handleUrlScan = async () => {
    if (!urlToScan) {
      toast.error('Please enter a URL');
      return;
    }

    setScanLoading(true);
    setScanResult(null);

    try {
      const { data, error } = await supabase.functions.invoke('url-security-scan', {
        body: { url: urlToScan },
      });

      if (error) {
        const errorMsg = await error?.context?.text();
        throw new Error(errorMsg || error.message);
      }

      setScanResult(data);
      toast.success('Scan complete!');
    } catch (error: any) {
      console.error('Error scanning URL:', error);
      toast.error(error.message || 'Failed to scan URL');
    } finally {
      setScanLoading(false);
    }
  };

  const handlePasswordCheck = async () => {
    if (!password) {
      toast.error('Please enter a password');
      return;
    }

    setPasswordLoading(true);
    setPasswordResult(null);

    try {
      const { data, error } = await supabase.functions.invoke('password-strength-check', {
        body: { password },
      });

      if (error) {
        const errorMsg = await error?.context?.text();
        throw new Error(errorMsg || error.message);
      }

      setPasswordResult(data);
      toast.success('Analysis complete!');
    } catch (error: any) {
      console.error('Error checking password:', error);
      toast.error(error.message || 'Failed to analyze password');
    } finally {
      setPasswordLoading(false);
    }
  };

  const getRiskBadge = (riskLevel: string) => {
    switch (riskLevel) {
      case 'low':
        return <Badge className="bg-green-500">Low Risk</Badge>;
      case 'medium':
        return <Badge className="bg-yellow-500">Medium Risk</Badge>;
      case 'high':
        return <Badge className="bg-red-500">High Risk</Badge>;
      default:
        return <Badge>Unknown</Badge>;
    }
  };

  const getStrengthBadge = (strength: string) => {
    switch (strength) {
      case 'weak':
        return <Badge className="bg-red-500">Weak</Badge>;
      case 'fair':
        return <Badge className="bg-orange-500">Fair</Badge>;
      case 'good':
        return <Badge className="bg-yellow-500">Good</Badge>;
      case 'strong':
        return <Badge className="bg-green-500">Strong</Badge>;
      case 'excellent':
        return <Badge className="bg-blue-500">Excellent</Badge>;
      default:
        return <Badge>Unknown</Badge>;
    }
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="space-y-2">
        <h1 className="text-3xl font-bold">Security Tools</h1>
        <p className="text-muted-foreground">
          Analyze URLs and check password strength with AI-powered security tools
        </p>
      </div>

      <Tabs defaultValue="url-scanner" className="space-y-6">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="url-scanner">URL Scanner</TabsTrigger>
          <TabsTrigger value="password-analyzer">Password Analyzer</TabsTrigger>
        </TabsList>

        <TabsContent value="url-scanner" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Shield className="h-5 w-5" />
                <span>URL Security Scanner</span>
              </CardTitle>
              <CardDescription>
                Analyze URLs for phishing, malware, and other security threats using AI
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="url">URL to Scan</Label>
                <div className="flex space-x-2">
                  <Input
                    id="url"
                    type="url"
                    placeholder="https://example.com"
                    value={urlToScan}
                    onChange={(e) => setUrlToScan(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleUrlScan()}
                  />
                  <Button onClick={handleUrlScan} disabled={scanLoading}>
                    {scanLoading ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        Scanning...
                      </>
                    ) : (
                      'Scan URL'
                    )}
                  </Button>
                </div>
              </div>

              {scanResult && (
                <Card className="border-2">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-base">Scan Results</CardTitle>
                      {getRiskBadge(scanResult.risk_level)}
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex items-start space-x-2">
                        {scanResult.risk_level === 'low' ? (
                          <CheckCircle className="h-5 w-5 text-green-500 mt-0.5" />
                        ) : (
                          <AlertTriangle className="h-5 w-5 text-yellow-500 mt-0.5" />
                        )}
                        <div className="flex-1">
                          <p className="font-medium">URL: {scanResult.url || urlToScan}</p>
                          <p className="text-sm text-muted-foreground mt-1">
                            {scanResult.explanation}
                          </p>
                        </div>
                      </div>
                    </div>

                    {scanResult.confidence && (
                      <div className="space-y-1">
                        <div className="flex justify-between text-sm">
                          <span>Confidence</span>
                          <span className="font-medium">{scanResult.confidence}%</span>
                        </div>
                        <div className="w-full bg-muted rounded-full h-2">
                          <div
                            className="bg-primary h-2 rounded-full transition-all"
                            style={{ width: `${scanResult.confidence}%` }}
                          />
                        </div>
                      </div>
                    )}

                    {scanResult.indicators && scanResult.indicators.length > 0 && (
                      <div className="space-y-2">
                        <p className="text-sm font-medium">Security Indicators:</p>
                        <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground">
                          {scanResult.indicators.map((indicator: string, idx: number) => (
                            <li key={idx}>{indicator}</li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {scanResult.recommendations && scanResult.recommendations.length > 0 && (
                      <div className="space-y-2">
                        <p className="text-sm font-medium">Recommendations:</p>
                        <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground">
                          {scanResult.recommendations.map((rec: string, idx: number) => (
                            <li key={idx}>{rec}</li>
                          ))}
                        </ul>
                      </div>
                    )}

                    <div className="grid grid-cols-2 gap-4 pt-2 border-t">
                      <div className="flex items-center space-x-2">
                        <Info className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm">
                          Phishing: {scanResult.is_phishing ? 'Detected' : 'Not detected'}
                        </span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Info className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm">
                          Malware: {scanResult.is_malware ? 'Detected' : 'Not detected'}
                        </span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="password-analyzer" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Shield className="h-5 w-5" />
                <span>Password Strength Analyzer</span>
              </CardTitle>
              <CardDescription>
                Evaluate password strength and get recommendations using AI analysis
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="password">Password to Analyze</Label>
                <div className="flex space-x-2">
                  <Input
                    id="password"
                    type="password"
                    placeholder="Enter password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handlePasswordCheck()}
                  />
                  <Button onClick={handlePasswordCheck} disabled={passwordLoading}>
                    {passwordLoading ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        Analyzing...
                      </>
                    ) : (
                      'Analyze'
                    )}
                  </Button>
                </div>
              </div>

              {passwordResult && (
                <Card className="border-2">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-base">Analysis Results</CardTitle>
                      {getStrengthBadge(passwordResult.strength)}
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Strength Score</span>
                        <span className="font-medium">{passwordResult.score}/100</span>
                      </div>
                      <div className="w-full bg-muted rounded-full h-2">
                        <div
                          className={`h-2 rounded-full transition-all ${
                            passwordResult.score >= 80
                              ? 'bg-green-500'
                              : passwordResult.score >= 60
                              ? 'bg-yellow-500'
                              : 'bg-red-500'
                          }`}
                          style={{ width: `${passwordResult.score}%` }}
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <p className="text-sm text-muted-foreground">Length</p>
                        <p className="font-medium">{passwordResult.length} characters</p>
                      </div>
                      {passwordResult.entropy && (
                        <div className="space-y-1">
                          <p className="text-sm text-muted-foreground">Entropy</p>
                          <p className="font-medium">{passwordResult.entropy.toFixed(1)} bits</p>
                        </div>
                      )}
                      {passwordResult.crack_time && (
                        <div className="space-y-1 col-span-2">
                          <p className="text-sm text-muted-foreground">Estimated Crack Time</p>
                          <p className="font-medium">{passwordResult.crack_time}</p>
                        </div>
                      )}
                    </div>

                    <div className="grid grid-cols-2 gap-2 pt-2 border-t">
                      <div className="flex items-center space-x-2">
                        {passwordResult.has_uppercase ? (
                          <CheckCircle className="h-4 w-4 text-green-500" />
                        ) : (
                          <AlertTriangle className="h-4 w-4 text-red-500" />
                        )}
                        <span className="text-sm">Uppercase</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        {passwordResult.has_lowercase ? (
                          <CheckCircle className="h-4 w-4 text-green-500" />
                        ) : (
                          <AlertTriangle className="h-4 w-4 text-red-500" />
                        )}
                        <span className="text-sm">Lowercase</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        {passwordResult.has_numbers ? (
                          <CheckCircle className="h-4 w-4 text-green-500" />
                        ) : (
                          <AlertTriangle className="h-4 w-4 text-red-500" />
                        )}
                        <span className="text-sm">Numbers</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        {passwordResult.has_symbols ? (
                          <CheckCircle className="h-4 w-4 text-green-500" />
                        ) : (
                          <AlertTriangle className="h-4 w-4 text-red-500" />
                        )}
                        <span className="text-sm">Symbols</span>
                      </div>
                    </div>

                    {passwordResult.issues && passwordResult.issues.length > 0 && (
                      <div className="space-y-2 pt-2 border-t">
                        <p className="text-sm font-medium">Issues Found:</p>
                        <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground">
                          {passwordResult.issues.map((issue: string, idx: number) => (
                            <li key={idx}>{issue}</li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {passwordResult.recommendations && passwordResult.recommendations.length > 0 && (
                      <div className="space-y-2 pt-2 border-t">
                        <p className="text-sm font-medium">Recommendations:</p>
                        <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground">
                          {passwordResult.recommendations.map((rec: string, idx: number) => (
                            <li key={idx}>{rec}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </CardContent>
                </Card>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
