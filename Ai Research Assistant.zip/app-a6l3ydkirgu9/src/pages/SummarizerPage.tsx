import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2, Plus, X, FileText, Save, Download } from 'lucide-react';
import { supabase } from '@/db/supabase';
import { createResearchItem, createSummary } from '@/db/api';
import { toast } from 'sonner';

interface SummaryResult {
  url: string;
  title: string;
  summary: string;
  keyPoints: string[];
  insights: string;
}

export default function SummarizerPage() {
  const [urls, setUrls] = useState<string[]>(['']);
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<SummaryResult[]>([]);
  const [summaryLength, setSummaryLength] = useState<'short' | 'medium' | 'long'>('medium');

  const addUrlField = () => {
    setUrls([...urls, '']);
  };

  const removeUrlField = (index: number) => {
    setUrls(urls.filter((_, i) => i !== index));
  };

  const updateUrl = (index: number, value: string) => {
    const newUrls = [...urls];
    newUrls[index] = value;
    setUrls(newUrls);
  };

  const handleSummarize = async () => {
    const validUrls = urls.filter((url) => url.trim() !== '');
    
    if (validUrls.length === 0) {
      toast.error('Please enter at least one URL');
      return;
    }

    setLoading(true);
    setResults([]);

    try {
      for (const url of validUrls) {
        // Extract webpage content
        const { data: extractData, error: extractError } = await supabase.functions.invoke('webpage-extract', {
          body: { url },
        });

        if (extractError) {
          toast.error(`Failed to extract content from ${url}: ${extractError.message}`);
          continue;
        }

        // Generate summary using AI
        const promptLength = summaryLength === 'short' ? '3-5 sentences' : summaryLength === 'medium' ? '1-2 paragraphs' : '3-4 paragraphs';
        const prompt = `Summarize the following article in ${promptLength}. Also provide 3-5 key points and important insights.

Title: ${extractData.title}
Content: ${extractData.text.substring(0, 5000)}

Format your response as:
SUMMARY:
[summary text]

KEY POINTS:
- [point 1]
- [point 2]
- [point 3]

INSIGHTS:
[insights text]`;

        const { data: summaryData, error: summaryError } = await supabase.functions.invoke('ai-summarize', {
          body: { prompt },
        });

        if (summaryError) {
          toast.error(`Failed to generate summary for ${url}: ${summaryError.message}`);
          continue;
        }

        // Parse the AI response
        const responseText = summaryData.text;
        const summaryMatch = responseText.match(/SUMMARY:\s*([\s\S]*?)(?=KEY POINTS:|$)/);
        const keyPointsMatch = responseText.match(/KEY POINTS:\s*([\s\S]*?)(?=INSIGHTS:|$)/);
        const insightsMatch = responseText.match(/INSIGHTS:\s*([\s\S]*?)$/);

        const summary = summaryMatch?.[1]?.trim() || responseText;
        const keyPointsText = keyPointsMatch?.[1]?.trim() || '';
        const keyPoints = keyPointsText
          .split('\n')
          .filter((line: string) => line.trim().startsWith('-'))
          .map((line: string) => line.replace(/^-\s*/, '').trim());
        const insights = insightsMatch?.[1]?.trim() || '';

        setResults((prev) => [
          ...prev,
          {
            url,
            title: extractData.title,
            summary,
            keyPoints,
            insights,
          },
        ]);
      }

      toast.success('Summarization complete!');
    } catch (error) {
      console.error('Error during summarization:', error);
      toast.error('An error occurred during summarization');
    } finally {
      setLoading(false);
    }
  };

  const handleSaveToLibrary = async (result: SummaryResult) => {
    try {
      // Create research item
      const researchItem = await createResearchItem({
        title: result.title,
        url: result.url,
        item_type: 'webpage',
        metadata: { summarized: true },
      });

      // Create summary
      await createSummary({
        research_item_id: researchItem.id,
        summary_text: result.summary,
        key_points: result.keyPoints,
        insights: result.insights,
      });

      toast.success('Saved to library!');
    } catch (error) {
      console.error('Error saving to library:', error);
      toast.error('Failed to save to library');
    }
  };

  const handleExport = (result: SummaryResult) => {
    const content = `# ${result.title}

**URL:** ${result.url}

## Summary
${result.summary}

## Key Points
${result.keyPoints.map((point) => `- ${point}`).join('\n')}

## Insights
${result.insights}
`;

    const blob = new Blob([content], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${result.title.replace(/[^a-z0-9]/gi, '_')}_summary.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="space-y-2">
        <h1 className="text-3xl font-bold">Webpage Summarizer</h1>
        <p className="text-muted-foreground">
          Extract and summarize content from web pages using AI
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Enter URLs to Summarize</CardTitle>
          <CardDescription>Add one or more URLs to generate AI-powered summaries</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>Summary Length</Label>
            <Select value={summaryLength} onValueChange={(value: any) => setSummaryLength(value)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="short">Short (3-5 sentences)</SelectItem>
                <SelectItem value="medium">Medium (1-2 paragraphs)</SelectItem>
                <SelectItem value="long">Long (3-4 paragraphs)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-3">
            {urls.map((url, index) => (
              <div key={index} className="flex space-x-2">
                <Input
                  placeholder="https://example.com/article"
                  value={url}
                  onChange={(e) => updateUrl(index, e.target.value)}
                  disabled={loading}
                />
                {urls.length > 1 && (
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => removeUrlField(index)}
                    disabled={loading}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                )}
              </div>
            ))}
          </div>

          <div className="flex space-x-2">
            <Button variant="outline" onClick={addUrlField} disabled={loading}>
              <Plus className="h-4 w-4 mr-2" />
              Add URL
            </Button>
            <Button onClick={handleSummarize} disabled={loading}>
              {loading ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Summarizing...
                </>
              ) : (
                <>
                  <FileText className="h-4 w-4 mr-2" />
                  Summarize
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Results */}
      {results.length > 0 && (
        <div className="space-y-4">
          <h2 className="text-2xl font-bold">Results</h2>
          {results.map((result, index) => (
            <Card key={index}>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="space-y-1 flex-1">
                    <CardTitle className="text-xl">{result.title}</CardTitle>
                    <CardDescription className="break-all">{result.url}</CardDescription>
                  </div>
                  <div className="flex space-x-2 ml-4">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleSaveToLibrary(result)}
                    >
                      <Save className="h-4 w-4 mr-2" />
                      Save
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleExport(result)}
                    >
                      <Download className="h-4 w-4 mr-2" />
                      Export
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="summary">
                  <TabsList>
                    <TabsTrigger value="summary">Summary</TabsTrigger>
                    <TabsTrigger value="keypoints">Key Points</TabsTrigger>
                    <TabsTrigger value="insights">Insights</TabsTrigger>
                  </TabsList>
                  <TabsContent value="summary" className="space-y-4">
                    <p className="text-sm leading-relaxed">{result.summary}</p>
                  </TabsContent>
                  <TabsContent value="keypoints" className="space-y-2">
                    {result.keyPoints.map((point, i) => (
                      <div key={i} className="flex items-start space-x-2">
                        <Badge variant="outline" className="mt-0.5">
                          {i + 1}
                        </Badge>
                        <p className="text-sm flex-1">{point}</p>
                      </div>
                    ))}
                  </TabsContent>
                  <TabsContent value="insights" className="space-y-4">
                    <p className="text-sm leading-relaxed">{result.insights}</p>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
