import { Navigate } from 'react-router-dom';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import DashboardPage from './pages/DashboardPage';
import SummarizerPage from './pages/SummarizerPage';
import LiteratureReviewPage from './pages/LiteratureReviewPage';
import ReportsPage from './pages/ReportsPage';
import LibraryPage from './pages/LibraryPage';
import SecurityPage from './pages/SecurityPage';
import WorkspacePage from './pages/WorkspacePage';
import DeveloperPlaygroundPage from './pages/DeveloperPlaygroundPage';
import AboutPage from './pages/AboutPage';
import AdminPage from './pages/AdminPage';
import SettingsPage from './pages/SettingsPage';
import NotFound from './pages/NotFound';
import RootRedirect from './pages/RootRedirect';
import AppLayout from './components/layouts/AppLayout';
import type { ReactNode } from 'react';

interface RouteConfig {
  name: string;
  path: string;
  element: ReactNode;
  visible?: boolean;
}

const routes: RouteConfig[] = [
  {
    name: 'Login',
    path: '/login',
    element: <LoginPage />,
    visible: false,
  },
  {
    name: 'Register',
    path: '/register',
    element: <RegisterPage />,
    visible: false,
  },
  {
    name: 'Dashboard',
    path: '/dashboard',
    element: (
      <AppLayout>
        <DashboardPage />
      </AppLayout>
    ),
  },
  {
    name: 'Summarizer',
    path: '/summarizer',
    element: (
      <AppLayout>
        <SummarizerPage />
      </AppLayout>
    ),
  },
  {
    name: 'Literature Review',
    path: '/literature-review',
    element: (
      <AppLayout>
        <LiteratureReviewPage />
      </AppLayout>
    ),
  },
  {
    name: 'Reports',
    path: '/reports',
    element: (
      <AppLayout>
        <ReportsPage />
      </AppLayout>
    ),
  },
  {
    name: 'Library',
    path: '/library',
    element: (
      <AppLayout>
        <LibraryPage />
      </AppLayout>
    ),
  },
  {
    name: 'Security',
    path: '/security',
    element: (
      <AppLayout>
        <SecurityPage />
      </AppLayout>
    ),
  },
  {
    name: 'Workspace',
    path: '/workspace',
    element: (
      <AppLayout>
        <WorkspacePage />
      </AppLayout>
    ),
  },
  {
    name: 'Developer Playground',
    path: '/playground',
    element: (
      <AppLayout>
        <DeveloperPlaygroundPage />
      </AppLayout>
    ),
  },
  {
    name: 'About',
    path: '/about',
    element: (
      <AppLayout>
        <AboutPage />
      </AppLayout>
    ),
  },
  {
    name: 'Admin',
    path: '/admin',
    element: (
      <AppLayout>
        <AdminPage />
      </AppLayout>
    ),
    visible: false,
  },
  {
    name: 'Settings',
    path: '/settings',
    element: (
      <AppLayout>
        <SettingsPage />
      </AppLayout>
    ),
    visible: false,
  },
  {
    name: 'Root',
    path: '/',
    element: <RootRedirect />,
    visible: false,
  },
  {
    name: 'Not Found',
    path: '*',
    element: <NotFound />,
    visible: false,
  },
];

export default routes;
