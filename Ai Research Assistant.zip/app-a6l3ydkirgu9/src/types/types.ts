// Database types matching Supabase schema

export type UserRole = 'user' | 'admin';
export type ProjectMemberRole = 'owner' | 'collaborator' | 'viewer';
export type ResearchItemType = 'webpage' | 'pdf' | 'note' | 'citation' | 'screenshot';
export type CitationFormat = 'APA' | 'MLA' | 'Chicago' | 'Harvard';

export interface Profile {
  id: string;
  email: string | null;
  username: string | null;
  role: UserRole;
  avatar_url: string | null;
  created_at: string;
  updated_at: string;
}

export interface Project {
  id: string;
  name: string;
  description: string | null;
  created_by: string;
  created_at: string;
  updated_at: string;
}

export interface ProjectMember {
  id: string;
  project_id: string;
  user_id: string;
  role: ProjectMemberRole;
  created_at: string;
}

export interface Folder {
  id: string;
  name: string;
  user_id: string;
  parent_id: string | null;
  created_at: string;
}

export interface Tag {
  id: string;
  name: string;
  user_id: string;
  created_at: string;
}

export interface ResearchItem {
  id: string;
  title: string;
  url: string | null;
  content: string | null;
  item_type: ResearchItemType;
  user_id: string;
  project_id: string | null;
  folder_id: string | null;
  metadata: Record<string, unknown>;
  created_at: string;
  updated_at: string;
}

export interface Summary {
  id: string;
  research_item_id: string;
  summary_text: string;
  key_points: string[];
  insights: string | null;
  user_id: string;
  created_at: string;
}

export interface Note {
  id: string;
  research_item_id: string;
  content: string;
  user_id: string;
  created_at: string;
  updated_at: string;
}

export interface Citation {
  id: string;
  research_item_id: string;
  format: CitationFormat;
  citation_text: string;
  user_id: string;
  created_at: string;
}

export interface Report {
  id: string;
  title: string;
  content: string;
  project_id: string | null;
  user_id: string;
  metadata: Record<string, unknown>;
  created_at: string;
  updated_at: string;
}

export interface KnowledgeGraphNode {
  id: string;
  project_id: string;
  label: string;
  node_type: string;
  metadata: Record<string, unknown>;
  created_at: string;
}

export interface KnowledgeGraphEdge {
  id: string;
  project_id: string;
  source_node_id: string;
  target_node_id: string;
  relationship: string;
  created_at: string;
}

// Extended types with relations
export interface ProjectWithMembers extends Project {
  project_members?: (ProjectMember & { profiles?: Profile })[];
}

export interface ResearchItemWithDetails extends ResearchItem {
  summaries?: Summary[];
  notes?: Note[];
  citations?: Citation[];
  tags?: Tag[];
}

// API request/response types
export interface SummarizeRequest {
  urls: string[];
  length?: 'short' | 'medium' | 'long';
}

export interface SummarizeResponse {
  url: string;
  title: string;
  summary: string;
  key_points: string[];
  insights: string;
}

export interface LiteratureReviewRequest {
  topic: string;
  research_question: string;
  source_ids: string[];
}

export interface LiteratureReviewResponse {
  review: string;
  themes: string[];
  comparison_table: Record<string, unknown>;
  citations: string[];
}

export interface ReportGenerateRequest {
  title: string;
  research_item_ids: string[];
  project_id?: string;
}

export interface ReportGenerateResponse {
  title: string;
  content: string;
  sections: {
    abstract: string;
    introduction: string;
    literature_review: string;
    key_findings: string;
    discussion: string;
    conclusion: string;
    references: string[];
  };
}

export interface VoiceCommandRequest {
  audio_url: string;
}

export interface VoiceCommandResponse {
  command: string;
  response: string;
  audio_url: string;
}

export interface URLScanResult {
  url: string;
  is_safe: boolean;
  threats: string[];
  risk_level: 'low' | 'medium' | 'high';
}

export interface PasswordStrengthResult {
  password: string;
  entropy: number;
  strength: 'weak' | 'fair' | 'good' | 'strong' | 'very_strong';
  crack_time: string;
  suggestions: string[];
}
