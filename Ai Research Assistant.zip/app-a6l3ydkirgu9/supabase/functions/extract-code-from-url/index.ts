import { corsHeaders } from '../_shared/cors.ts';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { url } = await req.json();

    if (!url) {
      return new Response(
        JSON.stringify({ error: 'URL is required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const apiKey = Deno.env.get('INTEGRATIONS_API_KEY');
    if (!apiKey) {
      throw new Error('INTEGRATIONS_API_KEY not configured');
    }

    // Step 1: Fetch webpage content using Webpage Content Extract API
    console.log('Fetching webpage content from:', url);
    const extractResponse = await fetch(
      `https://app-a6l3ydkirgu9-api-Q9KWZ8R7Qv09.gateway.appmedo.com/v3/article?url=${encodeURIComponent(url)}&fields=html,text`,
      {
        method: 'GET',
        headers: {
          'X-Gateway-Authorization': `Bearer ${apiKey}`,
        },
      }
    );

    if (!extractResponse.ok) {
      const errorText = await extractResponse.text();
      
      // Check for specific error codes
      if (extractResponse.status === 402) {
        throw new Error('API quota exceeded. Please try again later or contact support.');
      } else if (extractResponse.status === 429) {
        throw new Error('Too many requests. Please wait a moment and try again.');
      }
      
      throw new Error(`Failed to fetch webpage: ${extractResponse.status} - ${errorText}`);
    }

    const extractData = await extractResponse.json();
    const htmlContent = extractData.objects?.[0]?.html || extractData.objects?.[0]?.text || '';

    if (!htmlContent) {
      throw new Error('No content found on the webpage');
    }

    console.log('Webpage content fetched, length:', htmlContent.length);

    // Step 2: Direct HTML parsing (primary method)
    const result = {
      html: '',
      css: '',
      javascript: '',
      method: 'direct_parsing',
    };

    // Extract all style tags
    const styleMatches = htmlContent.matchAll(/<style[^>]*>([\s\S]*?)<\/style>/gi);
    const styles: string[] = [];
    for (const match of styleMatches) {
      if (match[1]) {
        styles.push(match[1].trim());
      }
    }
    result.css = styles.join('\n\n');

    // Extract all script tags (excluding external scripts)
    const scriptMatches = htmlContent.matchAll(/<script(?![^>]*src=)[^>]*>([\s\S]*?)<\/script>/gi);
    const scripts: string[] = [];
    for (const match of scriptMatches) {
      if (match[1] && match[1].trim()) {
        scripts.push(match[1].trim());
      }
    }
    result.javascript = scripts.join('\n\n');

    // Extract body content or main content
    let bodyMatch = htmlContent.match(/<body[^>]*>([\s\S]*?)<\/body>/i);
    if (bodyMatch) {
      let bodyContent = bodyMatch[1];
      
      // Remove script and style tags from body
      bodyContent = bodyContent.replace(/<script[^>]*>[\s\S]*?<\/script>/gi, '');
      bodyContent = bodyContent.replace(/<style[^>]*>[\s\S]*?<\/style>/gi, '');
      
      // Clean up excessive whitespace
      bodyContent = bodyContent.replace(/\n\s*\n\s*\n/g, '\n\n');
      
      result.html = bodyContent.trim();
    } else {
      // If no body tag, try to extract main content
      let cleanContent = htmlContent;
      cleanContent = cleanContent.replace(/<head[^>]*>[\s\S]*?<\/head>/gi, '');
      cleanContent = cleanContent.replace(/<script[^>]*>[\s\S]*?<\/script>/gi, '');
      cleanContent = cleanContent.replace(/<style[^>]*>[\s\S]*?<\/style>/gi, '');
      cleanContent = cleanContent.replace(/<!DOCTYPE[^>]*>/gi, '');
      cleanContent = cleanContent.replace(/<html[^>]*>/gi, '');
      cleanContent = cleanContent.replace(/<\/html>/gi, '');
      cleanContent = cleanContent.replace(/<body[^>]*>/gi, '');
      cleanContent = cleanContent.replace(/<\/body>/gi, '');
      
      result.html = cleanContent.trim().substring(0, 10000);
    }

    // Step 3: Optional AI enhancement (only if content is small enough)
    const totalContentLength = result.html.length + result.css.length + result.javascript.length;
    
    if (totalContentLength > 0 && totalContentLength < 8000) {
      try {
        console.log('Attempting AI enhancement...');
        
        const prompt = `Clean and optimize the following extracted code. Remove unnecessary comments, fix formatting, and make it production-ready.

HTML (${result.html.length} chars):
\`\`\`html
${result.html.substring(0, 3000)}
\`\`\`

CSS (${result.css.length} chars):
\`\`\`css
${result.css.substring(0, 2000)}
\`\`\`

JavaScript (${result.javascript.length} chars):
\`\`\`javascript
${result.javascript.substring(0, 2000)}
\`\`\`

Return the cleaned code in the same format with code blocks.`;

        const geminiResponse = await fetch(
          'https://app-a6l3ydkirgu9-api-VaOwP8E7dJqa.gateway.appmedo.com/v1beta/models/gemini-2.5-flash:streamGenerateContent?alt=sse',
          {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'X-Gateway-Authorization': `Bearer ${apiKey}`,
            },
            body: JSON.stringify({
              contents: [
                {
                  role: 'user',
                  parts: [{ text: prompt }],
                },
              ],
            }),
          }
        );

        if (geminiResponse.ok) {
          // Parse SSE stream
          const reader = geminiResponse.body?.getReader();
          const decoder = new TextDecoder();
          let fullText = '';

          if (reader) {
            while (true) {
              const { done, value } = await reader.read();
              if (done) break;

              const chunk = decoder.decode(value);
              const lines = chunk.split('\n');

              for (const line of lines) {
                if (line.startsWith('data: ')) {
                  const data = line.slice(6);
                  if (data.trim() === '') continue;

                  try {
                    const parsed = JSON.parse(data);
                    const text = parsed.candidates?.[0]?.content?.parts?.[0]?.text;
                    if (text) {
                      fullText += text;
                    }
                  } catch (e) {
                    // Skip invalid JSON
                  }
                }
              }
            }
          }

          // Try to extract enhanced code
          const htmlMatch = fullText.match(/```html\n([\s\S]*?)```/i);
          const cssMatch = fullText.match(/```css\n([\s\S]*?)```/i);
          const jsMatch = fullText.match(/```javascript\n([\s\S]*?)```/i) || 
                          fullText.match(/```js\n([\s\S]*?)```/i);

          if (htmlMatch || cssMatch || jsMatch) {
            result.html = htmlMatch ? htmlMatch[1].trim() : result.html;
            result.css = cssMatch ? cssMatch[1].trim() : result.css;
            result.javascript = jsMatch ? jsMatch[1].trim() : result.javascript;
            result.method = 'ai_enhanced';
          }
        } else {
          console.log('AI enhancement failed, using direct parsing result');
        }
      } catch (aiError) {
        console.log('AI enhancement error (non-critical):', aiError);
        // Continue with direct parsing result
      }
    }

    // Ensure we have some content
    if (!result.html && !result.css && !result.javascript) {
      throw new Error('Could not extract any code from the webpage. The page might be dynamically generated or protected.');
    }

    return new Response(
      JSON.stringify(result),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Error in extract-code-from-url:', error);
    
    // Provide user-friendly error messages
    let errorMessage = error.message || 'Internal server error';
    
    if (errorMessage.includes('402')) {
      errorMessage = 'API quota exceeded. The code extraction feature is temporarily unavailable. Please try again later.';
    } else if (errorMessage.includes('429')) {
      errorMessage = 'Too many requests. Please wait a moment before trying again.';
    }
    
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
