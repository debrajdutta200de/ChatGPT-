import { corsHeaders } from '../_shared/cors.ts';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { password } = await req.json();

    if (!password) {
      return new Response(
        JSON.stringify({ error: 'Password is required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Call Gemini API for password strength analysis
    const apiKey = Deno.env.get('INTEGRATIONS_API_KEY');
    if (!apiKey) {
      throw new Error('INTEGRATIONS_API_KEY not configured');
    }

    const prompt = `Evaluate the strength of this password: "${password}"

Please provide a detailed password strength analysis in the following JSON format:
{
  "strength": "weak" | "fair" | "good" | "strong" | "excellent",
  "score": 0-100,
  "entropy": number (bits of entropy),
  "crack_time": "estimated time to crack",
  "has_uppercase": true | false,
  "has_lowercase": true | false,
  "has_numbers": true | false,
  "has_symbols": true | false,
  "length": number,
  "issues": ["list of specific weaknesses found"],
  "recommendations": ["list of specific recommendations to improve"]
}

Evaluation criteria:
- Length: 8+ chars = fair, 12+ = good, 16+ = strong, 20+ = excellent
- Character variety: Must have uppercase, lowercase, numbers, and symbols for excellent
- Common patterns: Check for dictionary words, repeated characters, sequences (123, abc)
- Entropy calculation: Consider the character set size and length

Be accurate and fair in your assessment. A password with good length (12+) and variety (uppercase, lowercase, numbers, symbols) should be rated as "strong" or "excellent", not just "fair".`;

    const response = await fetch(
      'https://app-a6l3ydkirgu9-api-VaOwP8E7dJqa.gateway.appmedo.com/v1beta/models/gemini-2.5-flash:streamGenerateContent?alt=sse',
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Gateway-Authorization': `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          contents: [
            {
              role: 'user',
              parts: [{ text: prompt }],
            },
          ],
        }),
      }
    );

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Gemini API error: ${response.status} - ${errorText}`);
    }

    // Parse SSE stream
    const reader = response.body?.getReader();
    const decoder = new TextDecoder();
    let fullText = '';

    if (reader) {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        const chunk = decoder.decode(value);
        const lines = chunk.split('\n');

        for (const line of lines) {
          if (line.startsWith('data: ')) {
            const data = line.slice(6);
            if (data.trim() === '') continue;

            try {
              const parsed = JSON.parse(data);
              const text = parsed.candidates?.[0]?.content?.parts?.[0]?.text;
              if (text) {
                fullText += text;
              }
            } catch (e) {
              // Skip invalid JSON
            }
          }
        }
      }
    }

    // Extract JSON from response
    let analysisResult;
    try {
      // Try to find JSON in the response
      const jsonMatch = fullText.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        analysisResult = JSON.parse(jsonMatch[0]);
      } else {
        // Fallback: basic analysis
        const length = password.length;
        const hasUpper = /[A-Z]/.test(password);
        const hasLower = /[a-z]/.test(password);
        const hasNumber = /[0-9]/.test(password);
        const hasSymbol = /[^a-zA-Z0-9]/.test(password);

        const varietyCount = [hasUpper, hasLower, hasNumber, hasSymbol].filter(Boolean).length;
        
        let strength = 'weak';
        let score = 0;
        
        if (length >= 20 && varietyCount === 4) {
          strength = 'excellent';
          score = 95;
        } else if (length >= 16 && varietyCount >= 3) {
          strength = 'strong';
          score = 85;
        } else if (length >= 12 && varietyCount >= 3) {
          strength = 'strong';
          score = 80;
        } else if (length >= 10 && varietyCount >= 2) {
          strength = 'good';
          score = 65;
        } else if (length >= 8 && varietyCount >= 2) {
          strength = 'fair';
          score = 50;
        } else {
          strength = 'weak';
          score = 30;
        }

        analysisResult = {
          strength,
          score,
          entropy: length * Math.log2(26 * varietyCount),
          crack_time: 'Unknown',
          has_uppercase: hasUpper,
          has_lowercase: hasLower,
          has_numbers: hasNumber,
          has_symbols: hasSymbol,
          length,
          issues: [],
          recommendations: fullText ? [fullText] : ['Use a longer password with more variety'],
        };
      }
    } catch (e) {
      // Fallback analysis
      const length = password.length;
      analysisResult = {
        strength: length >= 12 ? 'good' : 'fair',
        score: Math.min(100, length * 5),
        entropy: length * 4,
        crack_time: 'Unknown',
        has_uppercase: /[A-Z]/.test(password),
        has_lowercase: /[a-z]/.test(password),
        has_numbers: /[0-9]/.test(password),
        has_symbols: /[^a-zA-Z0-9]/.test(password),
        length,
        issues: [],
        recommendations: ['Unable to fully analyze password'],
      };
    }

    return new Response(
      JSON.stringify(analysisResult),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Error in password-strength-check:', error);
    return new Response(
      JSON.stringify({ error: error.message || 'Internal server error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
