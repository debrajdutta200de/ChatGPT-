const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { query, year_start, year_end, start = 0 } = await req.json();

    if (!query) {
      return new Response(
        JSON.stringify({ error: 'Query is required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const apiKey = Deno.env.get('INTEGRATIONS_API_KEY');
    if (!apiKey) {
      throw new Error('INTEGRATIONS_API_KEY not configured');
    }

    // Build query parameters
    const params = new URLSearchParams({
      engine: 'google_scholar',
      q: query,
      hl: 'en',
      start: start.toString(),
    });

    if (year_start) {
      params.append('as_ylo', year_start.toString());
    }
    if (year_end) {
      params.append('as_yhi', year_end.toString());
    }

    // Call Google Scholar API
    const response = await fetch(
      `https://app-a6l3ydkirgu9-api-Xa6JZq2055oa.gateway.appmedo.com/search?${params.toString()}`,
      {
        method: 'GET',
        headers: {
          'X-Gateway-Authorization': `Bearer ${apiKey}`,
          'Accept': 'application/json',
        },
      }
    );

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`API error: ${response.status} - ${errorText}`);
    }

    const data = await response.json();

    return new Response(
      JSON.stringify({
        results: data.organic_results || [],
        total_results: data.search_information?.total_results || 0,
        pagination: data.pagination || {},
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Error in scholar-search:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
