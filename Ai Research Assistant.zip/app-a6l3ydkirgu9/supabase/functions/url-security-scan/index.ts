import { corsHeaders } from '../_shared/cors.ts';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { url } = await req.json();

    if (!url) {
      return new Response(
        JSON.stringify({ error: 'URL is required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Call Gemini API for URL security analysis
    const apiKey = Deno.env.get('INTEGRATIONS_API_KEY');
    if (!apiKey) {
      throw new Error('INTEGRATIONS_API_KEY not configured');
    }

    const prompt = `Analyze this URL for security risks and phishing indicators: ${url}

Please provide a detailed security analysis in the following JSON format:
{
  "risk_level": "low" | "medium" | "high",
  "is_phishing": true | false,
  "is_malware": true | false,
  "is_suspicious": true | false,
  "confidence": 0-100,
  "explanation": "detailed explanation of the analysis",
  "indicators": ["list of specific security indicators found"],
  "recommendations": ["list of recommendations for the user"]
}

Consider these factors:
- Domain reputation and age
- URL structure and patterns (suspicious characters, typosquatting)
- HTTPS/HTTP protocol
- Known phishing patterns
- Suspicious subdomains or paths
- Common legitimate domains vs suspicious ones

Be accurate and avoid false positives. Only flag as high risk if there are clear indicators of malicious intent.`;

    const response = await fetch(
      'https://app-a6l3ydkirgu9-api-VaOwP8E7dJqa.gateway.appmedo.com/v1beta/models/gemini-2.5-flash:streamGenerateContent?alt=sse',
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Gateway-Authorization': `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          contents: [
            {
              role: 'user',
              parts: [{ text: prompt }],
            },
          ],
        }),
      }
    );

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Gemini API error: ${response.status} - ${errorText}`);
    }

    // Parse SSE stream
    const reader = response.body?.getReader();
    const decoder = new TextDecoder();
    let fullText = '';

    if (reader) {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        const chunk = decoder.decode(value);
        const lines = chunk.split('\n');

        for (const line of lines) {
          if (line.startsWith('data: ')) {
            const data = line.slice(6);
            if (data.trim() === '') continue;

            try {
              const parsed = JSON.parse(data);
              const text = parsed.candidates?.[0]?.content?.parts?.[0]?.text;
              if (text) {
                fullText += text;
              }
            } catch (e) {
              // Skip invalid JSON
            }
          }
        }
      }
    }

    // Extract JSON from response
    let analysisResult;
    try {
      // Try to find JSON in the response
      const jsonMatch = fullText.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        analysisResult = JSON.parse(jsonMatch[0]);
      } else {
        // Fallback: parse the text response
        analysisResult = {
          risk_level: fullText.toLowerCase().includes('high') ? 'high' : 
                     fullText.toLowerCase().includes('medium') ? 'medium' : 'low',
          is_phishing: fullText.toLowerCase().includes('phishing'),
          is_malware: fullText.toLowerCase().includes('malware'),
          is_suspicious: fullText.toLowerCase().includes('suspicious'),
          confidence: 75,
          explanation: fullText,
          indicators: [],
          recommendations: ['Review the analysis carefully'],
        };
      }
    } catch (e) {
      analysisResult = {
        risk_level: 'low',
        is_phishing: false,
        is_malware: false,
        is_suspicious: false,
        confidence: 50,
        explanation: fullText || 'Unable to analyze URL',
        indicators: [],
        recommendations: [],
      };
    }

    return new Response(
      JSON.stringify(analysisResult),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Error in url-security-scan:', error);
    return new Response(
      JSON.stringify({ error: error.message || 'Internal server error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
