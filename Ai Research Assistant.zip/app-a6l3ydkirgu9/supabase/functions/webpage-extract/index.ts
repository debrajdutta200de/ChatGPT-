import { createClient } from 'jsr:@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { url, fields } = await req.json();

    if (!url) {
      return new Response(
        JSON.stringify({ error: 'URL is required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const apiKey = Deno.env.get('INTEGRATIONS_API_KEY');
    if (!apiKey) {
      throw new Error('INTEGRATIONS_API_KEY not configured');
    }

    // Call Webpage Content Extract API
    const apiUrl = new URL('https://app-a6l3ydkirgu9-api-Q9KWZ8R7Qv09.gateway.appmedo.com/v3/article');
    apiUrl.searchParams.append('url', url);
    if (fields) {
      apiUrl.searchParams.append('fields', fields);
    }

    const response = await fetch(apiUrl.toString(), {
      method: 'GET',
      headers: {
        'X-Gateway-Authorization': `Bearer ${apiKey}`,
      },
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`API error: ${response.status} - ${errorText}`);
    }

    const data = await response.json();

    // Extract the first object from the response
    const article = data.objects?.[0];
    if (!article) {
      throw new Error('No article content found');
    }

    return new Response(
      JSON.stringify({
        title: article.title || 'Untitled',
        text: article.text || '',
        html: article.html || '',
        author: article.author || article.authors?.[0]?.name || null,
        date: article.date || null,
        images: article.images || [],
        tags: article.tags || [],
        url: article.pageUrl || url,
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Error in webpage-extract:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
