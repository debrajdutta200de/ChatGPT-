-- Create user role enum
CREATE TYPE public.user_role AS ENUM ('user', 'admin');

-- Create project member role enum
CREATE TYPE public.project_member_role AS ENUM ('owner', 'collaborator', 'viewer');

-- Create research item type enum
CREATE TYPE public.research_item_type AS ENUM ('webpage', 'pdf', 'note', 'citation', 'screenshot');

-- Create citation format enum
CREATE TYPE public.citation_format AS ENUM ('APA', 'MLA', 'Chicago', 'Harvard');

-- Profiles table
CREATE TABLE public.profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text,
  username text UNIQUE,
  role public.user_role NOT NULL DEFAULT 'user'::public.user_role,
  avatar_url text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Projects table
CREATE TABLE public.projects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  created_by uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Project members table
CREATE TABLE public.project_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  role public.project_member_role NOT NULL DEFAULT 'viewer'::public.project_member_role,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(project_id, user_id)
);

-- Folders table
CREATE TABLE public.folders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  parent_id uuid REFERENCES public.folders(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Tags table
CREATE TABLE public.tags (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(name, user_id)
);

-- Research items table
CREATE TABLE public.research_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  url text,
  content text,
  item_type public.research_item_type NOT NULL,
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  project_id uuid REFERENCES public.projects(id) ON DELETE SET NULL,
  folder_id uuid REFERENCES public.folders(id) ON DELETE SET NULL,
  metadata jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Research item tags junction table
CREATE TABLE public.research_item_tags (
  research_item_id uuid NOT NULL REFERENCES public.research_items(id) ON DELETE CASCADE,
  tag_id uuid NOT NULL REFERENCES public.tags(id) ON DELETE CASCADE,
  PRIMARY KEY (research_item_id, tag_id)
);

-- Summaries table
CREATE TABLE public.summaries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  research_item_id uuid NOT NULL REFERENCES public.research_items(id) ON DELETE CASCADE,
  summary_text text NOT NULL,
  key_points jsonb DEFAULT '[]'::jsonb,
  insights text,
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Notes table
CREATE TABLE public.notes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  research_item_id uuid NOT NULL REFERENCES public.research_items(id) ON DELETE CASCADE,
  content text NOT NULL,
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Citations table
CREATE TABLE public.citations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  research_item_id uuid NOT NULL REFERENCES public.research_items(id) ON DELETE CASCADE,
  format public.citation_format NOT NULL,
  citation_text text NOT NULL,
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Reports table
CREATE TABLE public.reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  content text NOT NULL,
  project_id uuid REFERENCES public.projects(id) ON DELETE SET NULL,
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  metadata jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Knowledge graph nodes table
CREATE TABLE public.knowledge_graph_nodes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
  label text NOT NULL,
  node_type text NOT NULL,
  metadata jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Knowledge graph edges table
CREATE TABLE public.knowledge_graph_edges (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
  source_node_id uuid NOT NULL REFERENCES public.knowledge_graph_nodes(id) ON DELETE CASCADE,
  target_node_id uuid NOT NULL REFERENCES public.knowledge_graph_nodes(id) ON DELETE CASCADE,
  relationship text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Create indexes for performance
CREATE INDEX idx_projects_created_by ON public.projects(created_by);
CREATE INDEX idx_project_members_project_id ON public.project_members(project_id);
CREATE INDEX idx_project_members_user_id ON public.project_members(user_id);
CREATE INDEX idx_research_items_user_id ON public.research_items(user_id);
CREATE INDEX idx_research_items_project_id ON public.research_items(project_id);
CREATE INDEX idx_summaries_research_item_id ON public.summaries(research_item_id);
CREATE INDEX idx_notes_research_item_id ON public.notes(research_item_id);
CREATE INDEX idx_citations_research_item_id ON public.citations(research_item_id);
CREATE INDEX idx_knowledge_graph_nodes_project_id ON public.knowledge_graph_nodes(project_id);
CREATE INDEX idx_knowledge_graph_edges_project_id ON public.knowledge_graph_edges(project_id);

-- Create trigger function for user sync
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  user_count int;
BEGIN
  SELECT COUNT(*) INTO user_count FROM profiles;
  
  INSERT INTO public.profiles (id, email, username, role)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'username', split_part(NEW.email, '@', 1)),
    CASE WHEN user_count = 0 THEN 'admin'::public.user_role ELSE 'user'::public.user_role END
  );
  RETURN NEW;
END;
$$;

-- Create trigger for user sync
DROP TRIGGER IF EXISTS on_auth_user_confirmed ON auth.users;
CREATE TRIGGER on_auth_user_confirmed
  AFTER UPDATE ON auth.users
  FOR EACH ROW
  WHEN (OLD.confirmed_at IS NULL AND NEW.confirmed_at IS NOT NULL)
  EXECUTE FUNCTION handle_new_user();

-- Helper function to check if user is admin
CREATE OR REPLACE FUNCTION is_admin(uid uuid)
RETURNS boolean LANGUAGE sql SECURITY DEFINER AS $$
  SELECT EXISTS (
    SELECT 1 FROM profiles p
    WHERE p.id = uid AND p.role = 'admin'::user_role
  );
$$;

-- Helper function to check project access
CREATE OR REPLACE FUNCTION has_project_access(uid uuid, proj_id uuid)
RETURNS boolean LANGUAGE sql SECURITY DEFINER AS $$
  SELECT EXISTS (
    SELECT 1 FROM project_members pm
    WHERE pm.project_id = proj_id AND pm.user_id = uid
  );
$$;

-- Enable RLS
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.projects ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.project_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.folders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tags ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.research_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.research_item_tags ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.summaries ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.citations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.knowledge_graph_nodes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.knowledge_graph_edges ENABLE ROW LEVEL SECURITY;

-- Profiles policies
CREATE POLICY "Admins have full access to profiles" ON profiles
  FOR ALL TO authenticated USING (is_admin(auth.uid()));

CREATE POLICY "Users can view their own profile" ON profiles
  FOR SELECT TO authenticated USING (auth.uid() = id);

CREATE POLICY "Users can update their own profile" ON profiles
  FOR UPDATE TO authenticated USING (auth.uid() = id)
  WITH CHECK (role IS NOT DISTINCT FROM (SELECT role FROM profiles WHERE id = auth.uid()));

-- Public profiles view
CREATE VIEW public_profiles AS
  SELECT id, username, avatar_url, role FROM profiles;

-- Projects policies
CREATE POLICY "Admins have full access to projects" ON projects
  FOR ALL TO authenticated USING (is_admin(auth.uid()));

CREATE POLICY "Users can view projects they are members of" ON projects
  FOR SELECT TO authenticated USING (
    created_by = auth.uid() OR has_project_access(auth.uid(), id)
  );

CREATE POLICY "Users can create projects" ON projects
  FOR INSERT TO authenticated WITH CHECK (created_by = auth.uid());

CREATE POLICY "Project owners can update projects" ON projects
  FOR UPDATE TO authenticated USING (
    created_by = auth.uid() OR 
    EXISTS (
      SELECT 1 FROM project_members pm 
      WHERE pm.project_id = id AND pm.user_id = auth.uid() AND pm.role = 'owner'::project_member_role
    )
  );

CREATE POLICY "Project owners can delete projects" ON projects
  FOR DELETE TO authenticated USING (created_by = auth.uid());

-- Project members policies
CREATE POLICY "Admins have full access to project members" ON project_members
  FOR ALL TO authenticated USING (is_admin(auth.uid()));

CREATE POLICY "Users can view project members" ON project_members
  FOR SELECT TO authenticated USING (has_project_access(auth.uid(), project_id));

CREATE POLICY "Project owners can manage members" ON project_members
  FOR ALL TO authenticated USING (
    EXISTS (
      SELECT 1 FROM projects p 
      WHERE p.id = project_id AND p.created_by = auth.uid()
    ) OR
    EXISTS (
      SELECT 1 FROM project_members pm 
      WHERE pm.project_id = project_id AND pm.user_id = auth.uid() AND pm.role = 'owner'::project_member_role
    )
  );

-- Folders policies
CREATE POLICY "Users can manage their own folders" ON folders
  FOR ALL TO authenticated USING (user_id = auth.uid());

-- Tags policies
CREATE POLICY "Users can manage their own tags" ON tags
  FOR ALL TO authenticated USING (user_id = auth.uid());

-- Research items policies
CREATE POLICY "Admins have full access to research items" ON research_items
  FOR ALL TO authenticated USING (is_admin(auth.uid()));

CREATE POLICY "Users can view their own research items" ON research_items
  FOR SELECT TO authenticated USING (
    user_id = auth.uid() OR 
    (project_id IS NOT NULL AND has_project_access(auth.uid(), project_id))
  );

CREATE POLICY "Users can create research items" ON research_items
  FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can update their own research items" ON research_items
  FOR UPDATE TO authenticated USING (user_id = auth.uid());

CREATE POLICY "Users can delete their own research items" ON research_items
  FOR DELETE TO authenticated USING (user_id = auth.uid());

-- Research item tags policies
CREATE POLICY "Users can manage tags on their research items" ON research_item_tags
  FOR ALL TO authenticated USING (
    EXISTS (
      SELECT 1 FROM research_items ri 
      WHERE ri.id = research_item_id AND ri.user_id = auth.uid()
    )
  );

-- Summaries policies
CREATE POLICY "Users can view summaries of accessible research items" ON summaries
  FOR SELECT TO authenticated USING (
    user_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM research_items ri 
      WHERE ri.id = research_item_id AND (
        ri.user_id = auth.uid() OR 
        (ri.project_id IS NOT NULL AND has_project_access(auth.uid(), ri.project_id))
      )
    )
  );

CREATE POLICY "Users can create summaries" ON summaries
  FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());

-- Notes policies
CREATE POLICY "Users can manage their own notes" ON notes
  FOR ALL TO authenticated USING (user_id = auth.uid());

-- Citations policies
CREATE POLICY "Users can view citations of accessible research items" ON citations
  FOR SELECT TO authenticated USING (
    user_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM research_items ri 
      WHERE ri.id = research_item_id AND (
        ri.user_id = auth.uid() OR 
        (ri.project_id IS NOT NULL AND has_project_access(auth.uid(), ri.project_id))
      )
    )
  );

CREATE POLICY "Users can create citations" ON citations
  FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());

-- Reports policies
CREATE POLICY "Users can view their own reports and project reports" ON reports
  FOR SELECT TO authenticated USING (
    user_id = auth.uid() OR 
    (project_id IS NOT NULL AND has_project_access(auth.uid(), project_id))
  );

CREATE POLICY "Users can create reports" ON reports
  FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can update their own reports" ON reports
  FOR UPDATE TO authenticated USING (user_id = auth.uid());

CREATE POLICY "Users can delete their own reports" ON reports
  FOR DELETE TO authenticated USING (user_id = auth.uid());

-- Knowledge graph nodes policies
CREATE POLICY "Users can view nodes in accessible projects" ON knowledge_graph_nodes
  FOR SELECT TO authenticated USING (has_project_access(auth.uid(), project_id));

CREATE POLICY "Project collaborators can manage nodes" ON knowledge_graph_nodes
  FOR ALL TO authenticated USING (
    EXISTS (
      SELECT 1 FROM project_members pm 
      WHERE pm.project_id = project_id AND pm.user_id = auth.uid() 
      AND pm.role IN ('owner'::project_member_role, 'collaborator'::project_member_role)
    )
  );

-- Knowledge graph edges policies
CREATE POLICY "Users can view edges in accessible projects" ON knowledge_graph_edges
  FOR SELECT TO authenticated USING (has_project_access(auth.uid(), project_id));

CREATE POLICY "Project collaborators can manage edges" ON knowledge_graph_edges
  FOR ALL TO authenticated USING (
    EXISTS (
      SELECT 1 FROM project_members pm 
      WHERE pm.project_id = project_id AND pm.user_id = auth.uid() 
      AND pm.role IN ('owner'::project_member_role, 'collaborator'::project_member_role)
    )
  );